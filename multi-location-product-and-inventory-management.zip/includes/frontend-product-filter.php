<?php

/**
 * Filter products based on location
 *
 * @package Location_Wise_Products
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Location_Wise_Products_Filter
 */
class Location_Wise_Products_Filter
{
    /**
     * Constructor
     */
    public function __construct()
    {
        
    }

}

