<?php

/**
 * Plugin Name: Multi Location Product & Inventory Management for WooCommerce Pro
 * Plugin URI: https://plugincy.com/multi-location-product-and-inventory-management
 * Description: Filter WooCommerce products by store locations with a location selector for customers.
 * Version: 1.0.3.20
 * Author: plugincy
 * Author URI: https://plugincy.com/
 * Text Domain: multi-location-product-and-inventory-management
 * Requires at least: 5.0
 * Requires PHP: 7.2
 * WC requires at least: 4.0
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires Plugins: woocommerce
 */

if (!defined('ABSPATH')) exit;

if (!defined('MULTI_LOCATION_PLUGIN_URL')) {
    define('MULTI_LOCATION_PLUGIN_URL', plugin_dir_url(__FILE__));
}

if (!defined('mulopimfwc_VERSION')) {
    define("mulopimfwc_VERSION", "1.0.3.20");
}

// Check if the free version is installed and deactivate it if active
add_action('init', function () {
    if (is_plugin_active('multi-location-product-and-inventory-management/multi-location-product-and-inventory-management.php')) {
        deactivate_plugins('multi-location-product-and-inventory-management/multi-location-product-and-inventory-management.php');
        add_action('admin_notices', function () {
            echo '<div class="notice notice-warning is-dismissible"><p>';
            esc_html_e('Multi Location Product & Inventory Management for WooCommerce (free version) has been deactivated. Please use only the Pro version.', 'multi-location-product-and-inventory-management-pro');
            echo '</p></div>';
        });
    }
}, 1);

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    add_action('admin_notices', function () {
        echo '<div class="error"><p>' . esc_html_e('Location Wise Products requires WooCommerce to be installed and active.', 'multi-location-product-and-inventory-management') . '</p></div>';
    });
    return;
}


if (!function_exists('mulopimfwc_get_values')) {

    global $mulopimfwc_locations, $mulopimfwc_allowed_tags, $mulopimfwc_options;

    function mulopimfwc_get_values()
    {
        global $mulopimfwc_locations, $mulopimfwc_allowed_tags, $mulopimfwc_options;

        // Check if taxonomy exists
        if (!taxonomy_exists('mulopimfwc_store_location')) {
            error_log('Taxonomy mulopimfwc_store_location does not exist');
            return;
        }

        // Check if current user is a location manager
        $is_location_manager = false;
        $assigned_location_slugs = [];

        if (is_user_logged_in()) {
            $user = wp_get_current_user();
            if (in_array('mulopimfwc_location_manager', $user->roles)) {
                $is_location_manager = true;
                $assigned_location_slugs = get_user_meta($user->ID, 'mulopimfwc_assigned_locations', true);

                if (!is_array($assigned_location_slugs)) {
                    $assigned_location_slugs = [];
                }
            }
        }

        // Get locations based on user role
        if ($is_location_manager && !empty($assigned_location_slugs)) {
            // For location managers, only get their assigned locations
            $mulopimfwc_locations = get_terms([
                'taxonomy' => 'mulopimfwc_store_location',
                'hide_empty' => false,
                'slug' => $assigned_location_slugs,
            ]);
        } else {
            // For admins and other users, get all locations
            $mulopimfwc_locations = get_terms([
                'taxonomy' => 'mulopimfwc_store_location',
                'hide_empty' => false,
            ]);
        }

        $mulopimfwc_options = get_option('mulopimfwc_display_options') ?:
            [
                'enable_location_stock' => 'on',
                'enable_location_price' => 'on',
                'enable_location_backorder' => 'on',
                'enable_all_locations' => 'on',
                'location_change_notification' => 'on',
                'display_location_single_product' => 'on',
                'allow_data_share' => 'on',
                'strict_filtering' => 'enabled',

            ];

        $mulopimfwc_allowed_tags = array(
            'a' => array(
                'href' => array(),
                'title' => array(),
                'class' => array(),
                'target' => array(), // Allow target attribute for links
                'style' => array(),
                'id' => array(),
            ),
            'strong' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ),
            'em' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ),
            'li' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ),
            'div' => array(
                'class' => array(),
                'id' => array(), // Allow id for divs
                'style' => array(),
            ),
            'img' => array(
                'src' => array(),
                'alt' => array(),
                'class' => array(),
                'width' => array(), // Allow width attribute
                'height' => array(), // Allow height attribute
                'style' => array(),
                'id' => array(),
                'data-src' => array(),
            ),
            'h1' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ), // Allow h1
            'h2' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ),
            'h3' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ), // Allow h3
            'h4' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ), // Allow h4
            'h5' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ), // Allow h5
            'h6' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ), // Allow h6
            'span' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ),
            'p' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ),
            'br' => array(
                'style' => array(),
                'class' => array(),
            ), // Allow line breaks
            'blockquote' => array(
                'cite' => array(), // Allow cite attribute for blockquotes
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ),
            'table' => array(
                'class' => array(),
                'style' => array(), // Allow inline styles
                'id' => array(),
            ),
            'tr' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ),
            'td' => array(
                'class' => array(),
                'colspan' => array(), // Allow colspan attribute
                'rowspan' => array(), // Allow rowspan attribute
                'style' => array(),
                'id' => array(),
            ),
            'th' => array(
                'class' => array(),
                'colspan' => array(),
                'rowspan' => array(),
                'style' => array(),
                'id' => array(),
            ),
            'ul' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ), // Allow unordered lists
            'ol' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
            ), // Allow ordered lists
            'script' => array(
                'type' => array(),
                'src' => array(),
                'async' => array(),
                'defer' => array(),
                'charset' => array(),
            ), // Be cautious with scripts

            // Style and Meta Tags
            'style' => array(
                'type' => array(),
                'media' => array(),
                'scoped' => array(),
            ),
            'link' => array(
                'rel' => array(),
                'href' => array(),
                'type' => array(),
                'media' => array(),
                'sizes' => array(),
                'hreflang' => array(),
                'crossorigin' => array(),
            ),
            'meta' => array(
                'name' => array(),
                'content' => array(),
                'http-equiv' => array(),
                'charset' => array(),
                'property' => array(), // For Open Graph
            ),
            'title' => array(),
            'base' => array(
                'href' => array(),
                'target' => array(),
            ),

            // Document Structure
            'html' => array(
                'lang' => array(),
                'dir' => array(),
                'class' => array(),
                'style' => array(),
            ),
            'head' => array(),
            'body' => array(
                'class' => array(),
                'id' => array(),
                'style' => array(),
                'onload' => array(),
            ),
            'header' => array(
                'class' => array(),
                'id' => array(),
                'style' => array(),
                'role' => array(),
            ),
            'footer' => array(
                'class' => array(),
                'id' => array(),
                'style' => array(),
                'role' => array(),
            ),
            'nav' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
                'role' => array(),
            ),
            'main' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
                'role' => array(),
            ),
            'section' => array(
                'class' => array(),
                'id' => array(),
                'style' => array(),
                'role' => array(),
            ),
            'article' => array(
                'class' => array(),
                'style' => array(),
                'id' => array(),
                'role' => array(),
            ),
            'aside' => array(
                'class' => array(),
                'id' => array(),
                'style' => array(),
                'role' => array(),
            ),

            // Form Elements
            'form' => array(
                'action' => array(),
                'method' => array(),
                'style' => array(),
                'enctype' => array(),
                'target' => array(),
                'name' => array(),
                'id' => array(),
                'class' => array(),
                'autocomplete' => array(),
                'novalidate' => array(),
                'data-mobile-style' => array(),
                'data-product_show_settings' => array(),
                'data-product_selector' => array(),
                'data-pagination_selector' => array(),
                'data-layout' => array(),
            ),
            'input' => array(
                'type' => array(),
                'name' => array(),
                'value' => array(),
                'style' => array(),
                'placeholder' => array(),
                'id' => array(),
                'class' => array(),
                'required' => array(),
                'disabled' => array(),
                'readonly' => array(),
                'checked' => array(),
                'selected' => array(),
                'multiple' => array(),
                'min' => array(),
                'max' => array(),
                'step' => array(),
                'pattern' => array(),
                'maxlength' => array(),
                'minlength' => array(),
                'size' => array(),
                'autocomplete' => array(),
                'autofocus' => array(),
                'form' => array(),
                'formaction' => array(),
                'formmethod' => array(),
                'formtarget' => array(),
                'formnovalidate' => array(),
                'accept' => array(),
                'alt' => array(),
                'src' => array(),
                'width' => array(),
                'height' => array(),
            ),
            'textarea' => array(
                'name' => array(),
                'id' => array(),
                'class' => array(),
                'placeholder' => array(),
                'rows' => array(),
                'style' => array(),
                'cols' => array(),
                'required' => array(),
                'disabled' => array(),
                'readonly' => array(),
                'maxlength' => array(),
                'minlength' => array(),
                'wrap' => array(),
                'autocomplete' => array(),
                'autofocus' => array(),
                'form' => array(),
            ),
            'select' => array(
                'name' => array(),
                'id' => array(),
                'class' => array(),
                'multiple' => array(),
                'size' => array(),
                'required' => array(),
                'style' => array(),
                'disabled' => array(),
                'autofocus' => array(),
                'form' => array(),
            ),
            'option' => array(
                'value' => array(),
                'selected' => array(),
                'style' => array(),
                'disabled' => array(),
                'label' => array(),
            ),
            'optgroup' => array(
                'label' => array(),
                'style' => array(),
                'disabled' => array(),
            ),
            'button' => array(
                'type' => array(),
                'name' => array(),
                'value' => array(),
                'id' => array(),
                'style' => array(),
                'class' => array(),
                'disabled' => array(),
                'form' => array(),
                'formaction' => array(),
                'formmethod' => array(),
                'formtarget' => array(),
                'formnovalidate' => array(),
                'autofocus' => array(),
            ),
            'label' => array(
                'for' => array(),
                'form' => array(),
                'id' => array(),
                'class' => array(),
                'style' => array(),
            ),
            'fieldset' => array(
                'disabled' => array(),
                'form' => array(),
                'style' => array(),
                'name' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'legend' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'datalist' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'output' => array(
                'for' => array(),
                'form' => array(),
                'name' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'plugrogress' => array(
                'value' => array(),
                'max' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'meter' => array(
                'value' => array(),
                'min' => array(),
                'max' => array(),
                'low' => array(),
                'style' => array(),
                'high' => array(),
                'optimum' => array(),
                'id' => array(),
                'class' => array(),
            ),

            // Media Elements
            'audio' => array(
                'src' => array(),
                'controls' => array(),
                'autoplay' => array(),
                'style' => array(),
                'loop' => array(),
                'muted' => array(),
                'preload' => array(),
                'crossorigin' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'video' => array(
                'src' => array(),
                'controls' => array(),
                'autoplay' => array(),
                'loop' => array(),
                'muted' => array(),
                'preload' => array(),
                'style' => array(),
                'poster' => array(),
                'width' => array(),
                'height' => array(),
                'crossorigin' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'source' => array(
                'src' => array(),
                'style' => array(),
                'type' => array(),
                'media' => array(),
                'sizes' => array(),
                'srcset' => array(),
            ),
            'track' => array(
                'kind' => array(),
                'src' => array(),
                'style' => array(),
                'srclang' => array(),
                'label' => array(),
                'default' => array(),
            ),
            'embed' => array(
                'src' => array(),
                'type' => array(),
                'width' => array(),
                'height' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'object' => array(
                'data' => array(),
                'type' => array(),
                'style' => array(),
                'name' => array(),
                'width' => array(),
                'height' => array(),
                'form' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'param' => array(
                'name' => array(),
                'value' => array(),
                'style' => array(),
            ),
            'iframe' => array(
                'src' => array(),
                'srcdoc' => array(),
                'name' => array(),
                'width' => array(),
                'style' => array(),
                'height' => array(),
                'sandbox' => array(),
                'allow' => array(),
                'allowfullscreen' => array(),
                'loading' => array(),
                'id' => array(),
                'class' => array(),
            ),

            // Interactive Elements
            'details' => array(
                'open' => array(),
                'id' => array(),
                'class' => array(),
                'style' => array(),
            ),
            'summary' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'dialog' => array(
                'open' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),

            // Text Content Elements
            'pre' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'code' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'kbd' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'samp' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'var' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'small' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'sub' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'sup' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'mark' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'del' => array(
                'datetime' => array(),
                'style' => array(),
                'cite' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'ins' => array(
                'datetime' => array(),
                'style' => array(),
                'cite' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'q' => array(
                'cite' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'cite' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'abbr' => array(
                'title' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'dfn' => array(
                'title' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'time' => array(
                'datetime' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'data' => array(
                'value' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'address' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),

            // Table Elements (Enhanced)
            'caption' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'thead' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'tbody' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'tfoot' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'colgroup' => array(
                'span' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),
            'col' => array(
                'span' => array(),
                'style' => array(),
                'id' => array(),
                'class' => array(),
            ),

            // Definition Lists
            'dl' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'dt' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'dd' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),

            // Ruby Annotations
            'ruby' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'rt' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'rp' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),

            // Bidirectional Text
            'bdi' => array(
                'dir' => array(),
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'bdo' => array(
                'dir' => array(),
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),

            // Web Components
            'template' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'slot' => array(
                'name' => array(),
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),

            // Math and Science
            'math' => array(
                'display' => array(),
                'xmlns' => array(),
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),

            // Canvas and Graphics
            'canvas' => array(
                'width' => array(),
                'height' => array(),
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),

            // Obsolete but sometimes needed
            'center' => array(
                'id' => array(),
                'style' => array(),
                'class' => array(),
            ),
            'font' => array(
                'size' => array(),
                'style' => array(),
                'color' => array(),
                'face' => array(),
                'id' => array(),
                'class' => array(),
            ),

            // SVG Tags
            'svg' => array(
                'xmlns' => array(),
                'viewbox' => array(), // lowercase
                'viewBox' => array(), // camelCase (standard)
                'width' => array(),
                'height' => array(),
                'class' => array(),
                'id' => array(),
                'style' => array(),
                'preserveAspectRatio' => array(),
                'version' => array(),
                'x' => array(),
                'y' => array(),
                'fill' => array(),
            ),
            'g' => array(
                'class' => array(),
                'id' => array(),
                'transform' => array(),
                'style' => array(),
                'fill' => array(),
                'stroke' => array(),
                'opacity' => array(),
            ),
            'path' => array(
                'd' => array(),
                'class' => array(),
                'id' => array(),
                'fill' => array(),
                'stroke' => array(),
                'stroke-width' => array(),
                'stroke-dasharray' => array(),
                'stroke-linecap' => array(),
                'stroke-linejoin' => array(),
                'opacity' => array(),
                'transform' => array(),
                'style' => array(),
            ),
            'circle' => array(
                'cx' => array(),
                'cy' => array(),
                'r' => array(),
                'class' => array(),
                'id' => array(),
                'fill' => array(),
                'stroke' => array(),
                'stroke-width' => array(),
                'opacity' => array(),
                'transform' => array(),
                'style' => array(),
            ),
            'ellipse' => array(
                'cx' => array(),
                'cy' => array(),
                'rx' => array(),
                'ry' => array(),
                'class' => array(),
                'id' => array(),
                'fill' => array(),
                'stroke' => array(),
                'stroke-width' => array(),
                'opacity' => array(),
                'transform' => array(),
                'style' => array(),
            ),
            'rect' => array(
                'x' => array(),
                'y' => array(),
                'width' => array(),
                'height' => array(),
                'rx' => array(),
                'ry' => array(),
                'class' => array(),
                'id' => array(),
                'fill' => array(),
                'stroke' => array(),
                'stroke-width' => array(),
                'opacity' => array(),
                'transform' => array(),
                'style' => array(),
            ),
            'line' => array(
                'x1' => array(),
                'y1' => array(),
                'x2' => array(),
                'y2' => array(),
                'class' => array(),
                'id' => array(),
                'stroke' => array(),
                'stroke-width' => array(),
                'stroke-dasharray' => array(),
                'stroke-linecap' => array(),
                'opacity' => array(),
                'transform' => array(),
                'style' => array(),
            ),
            'polyline' => array(
                'points' => array(),
                'class' => array(),
                'id' => array(),
                'fill' => array(),
                'stroke' => array(),
                'stroke-width' => array(),
                'stroke-dasharray' => array(),
                'stroke-linecap' => array(),
                'stroke-linejoin' => array(),
                'opacity' => array(),
                'transform' => array(),
                'style' => array(),
            ),
            'polygon' => array(
                'points' => array(),
                'class' => array(),
                'id' => array(),
                'fill' => array(),
                'stroke' => array(),
                'stroke-width' => array(),
                'stroke-dasharray' => array(),
                'stroke-linecap' => array(),
                'stroke-linejoin' => array(),
                'opacity' => array(),
                'transform' => array(),
                'style' => array(),
            ),
            'text' => array(
                'x' => array(),
                'y' => array(),
                'dx' => array(),
                'dy' => array(),
                'class' => array(),
                'id' => array(),
                'fill' => array(),
                'stroke' => array(),
                'font-family' => array(),
                'font-size' => array(),
                'font-weight' => array(),
                'text-anchor' => array(),
                'dominant-baseline' => array(),
                'opacity' => array(),
                'transform' => array(),
                'style' => array(),
            ),
            'tspan' => array(
                'x' => array(),
                'y' => array(),
                'dx' => array(),
                'dy' => array(),
                'class' => array(),
                'id' => array(),
                'fill' => array(),
                'stroke' => array(),
                'font-family' => array(),
                'font-size' => array(),
                'font-weight' => array(),
                'text-anchor' => array(),
                'dominant-baseline' => array(),
                'opacity' => array(),
                'style' => array(),
            ),
            'use' => array(
                'href' => array(),
                'xlink:href' => array(),
                'x' => array(),
                'y' => array(),
                'width' => array(),
                'height' => array(),
                'class' => array(),
                'id' => array(),
                'transform' => array(),
                'style' => array(),
            ),
            'defs' => array(
                'class' => array(),
                'id' => array(),
                'style' => array(),
            ),
            'symbol' => array(
                'id' => array(),
                'viewBox' => array(),
                'class' => array(),
                'style' => array(),
                'preserveAspectRatio' => array(),
            ),
            'marker' => array(
                'id' => array(),
                'markerWidth' => array(),
                'markerHeight' => array(),
                'refX' => array(),
                'refY' => array(),
                'style' => array(),
                'orient' => array(),
                'markerUnits' => array(),
                'class' => array(),
            ),
            'linearGradient' => array(
                'id' => array(),
                'x1' => array(),
                'y1' => array(),
                'style' => array(),
                'x2' => array(),
                'y2' => array(),
                'gradientUnits' => array(),
                'gradientTransform' => array(),
                'class' => array(),
            ),
            'lineargradient' => array(
                'id' => array(),
                'x1' => array(),
                'y1' => array(),
                'style' => array(),
                'x2' => array(),
                'y2' => array(),
                'gradientUnits' => array(),
                'gradientTransform' => array(),
                'class' => array(),
            ),
            'radialGradient' => array(
                'id' => array(),
                'cx' => array(),
                'cy' => array(),
                'style' => array(),
                'r' => array(),
                'fx' => array(),
                'fy' => array(),
                'gradientUnits' => array(),
                'gradientTransform' => array(),
                'class' => array(),
            ),
            'radialgradient' => array(
                'id' => array(),
                'cx' => array(),
                'cy' => array(),
                'r' => array(),
                'style' => array(),
                'fx' => array(),
                'fy' => array(),
                'gradientUnits' => array(),
                'gradientTransform' => array(),
                'class' => array(),
            ),
            'stop' => array(
                'offset' => array(),
                'stop-color' => array(),
                'stop-opacity' => array(),
                'class' => array(),
                'style' => array(),
            ),
            'clipPath' => array(
                'id' => array(),
                'class' => array(),
                'style' => array(),
                'clipPathUnits' => array(),
            ),
            'mask' => array(
                'id' => array(),
                'class' => array(),
                'style' => array(),
                'maskUnits' => array(),
                'maskContentUnits' => array(),
                'x' => array(),
                'y' => array(),
                'width' => array(),
                'height' => array(),
            ),
            'pattern' => array(
                'id' => array(),
                'x' => array(),
                'y' => array(),
                'width' => array(),
                'style' => array(),
                'height' => array(),
                'patternUnits' => array(),
                'patternContentUnits' => array(),
                'patternTransform' => array(),
                'viewBox' => array(),
                'class' => array(),
            ),
            'filter' => array(
                'id' => array(),
                'x' => array(),
                'y' => array(),
                'style' => array(),
                'width' => array(),
                'height' => array(),
                'filterUnits' => array(),
                'primitiveUnits' => array(),
                'class' => array(),
            ),
            'feGaussianBlur' => array(
                'in' => array(),
                'style' => array(),
                'stdDeviation' => array(),
                'result' => array(),
            ),
            'feOffset' => array(
                'in' => array(),
                'dx' => array(),
                'style' => array(),
                'dy' => array(),
                'result' => array(),
            ),
            'feDropShadow' => array(
                'dx' => array(),
                'dy' => array(),
                'style' => array(),
                'stdDeviation' => array(),
                'flood-color' => array(),
                'flood-opacity' => array(),
            ),
            'image' => array(
                'x' => array(),
                'y' => array(),
                'width' => array(),
                'style' => array(),
                'height' => array(),
                'href' => array(),
                'xlink:href' => array(),
                'preserveAspectRatio' => array(),
                'class' => array(),
                'id' => array(),
                'opacity' => array(),
                'transform' => array(),
            ),
        );
    }

    add_action('init', 'mulopimfwc_get_values', 11);

    require_once plugin_dir_path(__FILE__) . 'admin/settings.php';
    require_once plugin_dir_path(__FILE__) . 'admin/dashboard.php';
    require_once plugin_dir_path(__FILE__) . 'admin/license-page.php';
    require_once plugin_dir_path(__FILE__) . 'admin/stock-central.php';
    require_once plugin_dir_path(__FILE__) . 'admin/admin.php';
    require_once plugin_dir_path(__FILE__) . 'includes/product-display.php';
    require_once plugin_dir_path(__FILE__) . 'admin/location-based-everythings.php';
    require_once plugin_dir_path(__FILE__) . 'admin/location-managers.php';
    require_once plugin_dir_path(__FILE__) . 'includes/product-location-selector-single.php';
    require_once plugin_dir_path(__FILE__) . 'admin/import-export-settings.php';
    require_once plugin_dir_path(__FILE__) . 'includes/location-based-shipping.php';
    require_once plugin_dir_path(__FILE__) . 'includes/location-wise-shipping-payment-tax.php';
    require_once plugin_dir_path(__FILE__) . 'includes/location-wise-coupons.php';
    require_once plugin_dir_path(__FILE__) . 'includes/location-wise-reviews.php';
    require_once plugin_dir_path(__FILE__) . 'includes/location-wise-seo.php';
    require_once plugin_dir_path(__FILE__) . 'includes/location-wise-email.php';
    require_once plugin_dir_path(__FILE__) . 'includes/frontend-location-information.php';
    require_once plugin_dir_path(__FILE__) . 'includes/location-wise-local-pickup.php';
    require_once plugin_dir_path(__FILE__) . 'includes/location-hours-restriction.php';
    require_once plugin_dir_path(__FILE__) . 'includes/customer-location-insights.php';



    class mulopimfwc_Location_Wise_Products
    {

        private $cart_items_cache = null;
        private $should_group_cache = null;

        public function __construct()
        {
            add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
            add_action('pre_get_posts', [$this, 'filter_products_by_location']);
            add_filter('woocommerce_shortcode_products_query', [$this, 'filter_shortcode_products']);
            add_filter('woocommerce_products_widget_query_args', [$this, 'filter_widget_products']);
            add_filter('woocommerce_related_products_args', [$this, 'filter_related_products']);
            $options = get_option('mulopimfwc_display_options', ['enable_popup' => 'off']);
            if (isset($options['enable_popup']) && $options['enable_popup'] === 'on' && mulopimfwc_premium_feature()) {
                add_action('wp_footer', [$this, 'location_selector_modal']);
            }
            add_action('init', [$this, 'clear_cart_on_location_change']);

            add_shortcode('mulopimfwc_store_location_selector', [$this, 'location_selector_shortcode']);

            add_filter('the_title', [$this, 'add_location_to_product_title'], 10, 2);
            add_filter('woocommerce_product_title', [$this, 'add_location_to_wc_product_title'], 10, 2);
            global $MULOPIMFWC_Admin;
            $MULOPIMFWC_Admin = new MULOPIMFWC_Admin();
            add_filter('woocommerce_related_products', [$this, 'filter_related_products_by_location'], 10, 3);
            add_filter('woocommerce_recently_viewed_products_widget_query_args', [$this, 'filter_widget_products_by_location']);
            add_filter('woocommerce_cross_sells_products', [$this, 'filter_cross_sells_by_location'], 10, 1);
            add_filter('woocommerce_upsells_products', [$this, 'filter_upsells_by_location'], 10, 2);
            add_filter('woocommerce_blocks_product_grid_item_html', [$this, 'filter_product_blocks'], 10, 3);
            add_filter('woocommerce_json_search_found_products', [$this, 'filter_ajax_searched_products']);
            add_filter('woocommerce_rest_product_object_query', [$this, 'filter_rest_api_products'], 10, 2);
            add_filter('woocommerce_rest_prepare_product_object', [$this, 'modify_product_rest_response'], 10, 3);
            add_filter('woocommerce_cart_contents', [$this, 'filter_cart_contents'], 10, 1);
            add_action('template_redirect', [$this, 'filter_recently_viewed_products']);

            add_action('wp_ajax_clear_cart', [$this, 'clear_cart']);
            add_action('wp_ajax_nopriv_clear_cart', [$this, 'clear_cart']);

            add_action('wp_ajax_check_cart_products', [$this, 'check_cart_products']);
            add_action('wp_ajax_nopriv_check_cart_products', [$this, 'check_cart_products']);

            add_action('admin_enqueue_scripts', [$this, 'custom_admin_styles']);

            // add settings button after deactivate button in plugins page

            add_action('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'add_settings_link']);
            add_action('admin_init', [$this, 'add_settings_link']);

            // Save location to order meta
            add_action('woocommerce_thankyou', array($this, 'save_location_to_order_meta'), 10, 2);

            // Use these specific hooks for HPOS orders table
            add_action('woocommerce_order_list_table_restrict_manage_orders', array($this, 'add_store_location_filter'));
            add_filter('woocommerce_order_query_args', array($this, 'filter_orders_by_location'));

            require_once plugin_dir_path(__FILE__) . 'includes/stock-price-backorder-manage.php';

            add_action('wp_ajax_update_product_location_status', [$this, 'cymulopimfwc_update_product_location_status']);
            add_action('wp_ajax_get_available_locations', [$this, 'cymulopimfwc_get_available_locations']);
            add_action('wp_ajax_save_product_locations', [$this, 'cymulopimfwc_save_product_locations']);

            add_action('admin_enqueue_scripts', [$this, 'cymulopimfwc_enqueue_admin_scripts']);

            // Mixed location cart tracking
            add_filter('woocommerce_add_cart_item_data', [$this, 'add_location_to_cart_item'], 10, 3);
            add_filter('woocommerce_get_item_data', [$this, 'display_location_in_cart'], 10, 2);
            add_action('woocommerce_checkout_create_order_line_item', [$this, 'save_location_to_order_item'], 10, 4);
            add_action('woocommerce_before_order_itemmeta', [$this, 'display_location_in_order_items'], 10, 3);
            add_action('woocommerce_check_cart_items', [$this, 'validate_mixed_cart_locations']);
            add_action('woocommerce_before_cart_table', [$this, 'display_cart_location_summary']);

            // Cart grouping by location
            add_action('woocommerce_before_cart_table', [$this, 'maybe_override_cart_display'], 5);
            add_action('woocommerce_after_cart_table', [$this, 'maybe_restore_cart_display'], 5);

            // Only add checkout hooks if on checkout page
            add_action('woocommerce_review_order_before_cart_contents', [$this, 'maybe_override_checkout_cart_display'], 5);
            add_action('woocommerce_review_order_after_cart_contents', [$this, 'maybe_restore_checkout_cart_display'], 5);


            // Clear cache when cart changes
            add_action('woocommerce_cart_item_removed', [$this, 'clear_cart_cache']);
            add_action('woocommerce_cart_item_restored', [$this, 'clear_cart_cache']);
            add_action('woocommerce_after_cart_item_quantity_update', [$this, 'clear_cart_cache']);
            add_action('woocommerce_add_to_cart', [$this, 'clear_cart_cache']);

            // inter_location_transfer_costs

            add_action('woocommerce_cart_calculate_fees', [$this, 'add_inter_location_transfer_fees']);
            add_filter('woocommerce_cart_shipping_packages', [$this, 'split_shipping_packages_by_location']);

            // display the notice for transfer cost breakdown
            add_action('woocommerce_before_cart_totals', [$this, 'display_transfer_cost_breakdown']);
            add_action('woocommerce_review_order_before_order_total', [$this, 'display_transfer_cost_breakdown']);
            // Save transfer cost details to order meta
            add_action('woocommerce_checkout_order_processed', [$this, 'save_transfer_costs_to_order'], 10, 1);
            // Display transfer costs in admin order details
            add_action('woocommerce_admin_order_data_after_order_details', [$this, 'display_transfer_costs_in_order'], 10, 1);
        }

        /**
         * Clear cart items cache
         */
        public function clear_cart_cache()
        {
            $this->cart_items_cache = null;
        }

        /**
         * Display transfer costs in order details (admin)
         */
        public function display_transfer_costs_in_order($order)
        {
            $transfer_costs = $order->get_meta('_inter_location_transfer_costs');

            if (empty($transfer_costs) || !is_array($transfer_costs)) {
                return;
            }

            $destination = $order->get_meta('_destination_location');

?>
            <div class="mulopimfwc-order-transfer-costs" style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-left: 4px solid #3b82f6; border-radius: 4px;">
                <h4 style="margin-top: 0; color: #1e40af;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align: middle; margin-right: 5px;">
                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="currentColor" />
                    </svg>
                    <?php esc_html_e('Inter-Location Transfer Costs', 'multi-location-product-and-inventory-management'); ?>
                </h4>

                <?php if (!empty($destination)): ?>
                    <p style="margin: 5px 0; color: #64748b; font-size: 13px;">
                        <?php echo sprintf(esc_html__('Destination: %s', 'multi-location-product-and-inventory-management'), '<strong>' . esc_html($destination) . '</strong>'); ?>
                    </p>
                <?php endif; ?>

                <table class="widefat" style="margin-top: 10px; border: 1px solid #e2e8f0;">
                    <thead>
                        <tr>
                            <th style="padding: 8px; background: #f1f5f9; border-bottom: 1px solid #e2e8f0;"><?php esc_html_e('From Location', 'multi-location-product-and-inventory-management'); ?></th>
                            <th style="padding: 8px; background: #f1f5f9; border-bottom: 1px solid #e2e8f0;"><?php esc_html_e('To Location', 'multi-location-product-and-inventory-management'); ?></th>
                            <th style="padding: 8px; background: #f1f5f9; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php esc_html_e('Cost', 'multi-location-product-and-inventory-management'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $total = 0;
                        foreach ($transfer_costs as $transfer):
                            $total += $transfer['cost'];
                        ?>
                            <tr>
                                <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;"><?php echo esc_html($transfer['from']); ?></td>
                                <td style="padding: 8px; border-bottom: 1px solid #e2e8f0;"><?php echo esc_html($transfer['to']); ?></td>
                                <td style="padding: 8px; border-bottom: 1px solid #e2e8f0; text-align: right;"><?php echo wc_price($transfer['cost']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td colspan="2" style="padding: 8px; font-weight: bold; background: #f8fafc;"><?php esc_html_e('Total Transfer Cost', 'multi-location-product-and-inventory-management'); ?></td>
                            <td style="padding: 8px; font-weight: bold; text-align: right; background: #f8fafc;"><?php echo wc_price($total); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php
        }

        /**
         * Save transfer cost information to order meta
         */
        public function save_transfer_costs_to_order($order_id)
        {
            global $mulopimfwc_options;

            // Check if mixed location cart is enabled
            $allow_mixed = isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['allow_mixed_location_cart']
                : 'off';

            if ($allow_mixed !== 'on') {
                return;
            }

            $order = wc_get_order($order_id);
            if (!$order) {
                return;
            }

            // Get user's selected location
            $selected_location = $this->get_current_location();

            if (empty($selected_location) || $selected_location === 'all-products') {
                return;
            }

            // Get transfer costs settings
            $options = get_option('mulopimfwc_display_options', []);
            $transfer_costs = isset($options['inter_location_transfer_costs']) && mulopimfwc_premium_feature()
                ? $options['inter_location_transfer_costs']
                : [];

            if (empty($transfer_costs)) {
                return;
            }

            // Get selected location term
            $destination_term = get_term_by('slug', $selected_location, 'mulopimfwc_store_location');
            if (!$destination_term || is_wp_error($destination_term)) {
                return;
            }

            $destination_slug = $destination_term->slug;
            $transfer_details = [];

            // Get cart items grouped by location
            $items_by_location = $this->get_cart_items_by_location();

            // Collect transfer cost details
            foreach ($items_by_location as $location_data) {
                $source_slug = $location_data['location_slug'];

                if ($source_slug === $destination_slug || $source_slug === 'unknown') {
                    continue;
                }

                $cost_key = $source_slug . '_to_' . $destination_slug;

                if (isset($transfer_costs[$cost_key]) && !empty($transfer_costs[$cost_key])) {
                    $cost = floatval($transfer_costs[$cost_key]);

                    if ($cost > 0) {
                        $transfer_details[] = [
                            'from' => $location_data['location_name'],
                            'to' => $destination_term->name,
                            'cost' => $cost
                        ];
                    }
                }
            }

            // Save transfer details to order meta
            if (!empty($transfer_details)) {
                $order->update_meta_data('_inter_location_transfer_costs', $transfer_details);
                $order->update_meta_data('_destination_location', $destination_term->name);
                $order->save();
            }
        }


        /**
         * Add inter-location transfer fees to cart
         */
        public function add_inter_location_transfer_fees()
        {
            global $mulopimfwc_options;

            // Check if mixed location cart is enabled
            $allow_mixed = isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['allow_mixed_location_cart']
                : 'off';

            if ($allow_mixed !== 'on') {
                return;
            }

            // Get user's selected location (destination)
            $selected_location = $this->get_current_location();

            if (empty($selected_location) || $selected_location === 'all-products') {
                return;
            }

            // Get transfer costs settings
            $options = get_option('mulopimfwc_display_options', []);
            $transfer_costs = isset($options['inter_location_transfer_costs']) && mulopimfwc_premium_feature()
                ? $options['inter_location_transfer_costs']
                : [];

            if (empty($transfer_costs)) {
                return;
            }

            // Get selected location term
            $destination_term = get_term_by('slug', $selected_location, 'mulopimfwc_store_location');
            if (!$destination_term || is_wp_error($destination_term)) {
                return;
            }

            $destination_slug = $destination_term->slug;
            $total_transfer_cost = 0;
            $transfer_details = [];

            // Get cart items grouped by location
            $items_by_location = $this->get_cart_items_by_location();

            // Calculate transfer costs for each source location
            foreach ($items_by_location as $location_data) {
                $source_slug = $location_data['location_slug'];

                // Skip if it's the same location or unknown
                if ($source_slug === $destination_slug || $source_slug === 'unknown') {
                    continue;
                }

                // Build the cost key: source_to_destination
                $cost_key = $source_slug . '_to_' . $destination_slug;

                // Check if transfer cost exists for this route
                if (isset($transfer_costs[$cost_key]) && !empty($transfer_costs[$cost_key])) {
                    $cost = floatval($transfer_costs[$cost_key]);

                    if ($cost > 0) {
                        $total_transfer_cost += $cost;
                        $transfer_details[] = sprintf(
                            __('%s to %s: %s', 'multi-location-product-and-inventory-management'),
                            $location_data['location_name'],
                            $destination_term->name,
                            $cost
                        );
                    }
                }
            }

            // Add transfer cost as a fee if greater than zero
            if ($total_transfer_cost > 0) {
                $fee_label = __('Inter-location Transfer', 'multi-location-product-and-inventory-management');

                // Add detailed breakdown if multiple transfers
                if (count($transfer_details) > 1) {
                    $fee_label .= ' (' . implode(', ', $transfer_details) . ')';
                } elseif (count($transfer_details) === 1) {
                    $fee_label .= ' (' . $transfer_details[0] . ')';
                }

                WC()->cart->add_fee($fee_label, $total_transfer_cost, true);
            }
        }

        /**
         * Split shipping packages by location for accurate shipping calculation
         */
        public function split_shipping_packages_by_location($packages)
        {
            global $mulopimfwc_options;

            // Check if mixed location cart is enabled
            $allow_mixed = isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['allow_mixed_location_cart']
                : 'off';

            if ($allow_mixed !== 'on') {
                return $packages;
            }

            // Check if location-based shipping is enabled
            $enable_location_shipping = isset($mulopimfwc_options['enable_location_shipping']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['enable_location_shipping']
                : 'off';

            if ($enable_location_shipping !== 'on') {
                return $packages;
            }

            // Get cart items grouped by location
            $items_by_location = $this->get_cart_items_by_location();

            if (count($items_by_location) <= 1) {
                return $packages;
            }

            // Create separate shipping packages for each location
            $new_packages = [];
            $package_index = 1;

            foreach ($items_by_location as $location_data) {
                $location_slug = $location_data['location_slug'];
                $location_name = $location_data['location_name'];

                // Create package for this location
                $package_contents = [];
                $package_contents_cost = 0;

                foreach ($location_data['items'] as $cart_item) {
                    $package_contents[$cart_item['cart_item_key']] = $cart_item;
                    $package_contents_cost += $cart_item['line_total'];
                }

                $new_packages['location_' . $location_slug . '_' . $package_index] = [
                    'contents' => $package_contents,
                    'contents_cost' => $package_contents_cost,
                    'applied_coupons' => WC()->cart->get_applied_coupons(),
                    'user' => [
                        'ID' => get_current_user_id()
                    ],
                    'destination' => [
                        'country' => WC()->customer->get_shipping_country(),
                        'state' => WC()->customer->get_shipping_state(),
                        'postcode' => WC()->customer->get_shipping_postcode(),
                        'city' => WC()->customer->get_shipping_city(),
                        'address' => WC()->customer->get_shipping_address(),
                        'address_2' => WC()->customer->get_shipping_address_2()
                    ],
                    'location_slug' => $location_slug,
                    'location_name' => $location_name,
                    'package_name' => sprintf(
                        __('Shipping from %s', 'multi-location-product-and-inventory-management'),
                        $location_name
                    )
                ];

                $package_index++;
            }

            return !empty($new_packages) ? $new_packages : $packages;
        }

        /**
         * Display transfer cost breakdown in cart totals
         */
        public function display_transfer_cost_breakdown()
        {
            global $mulopimfwc_options;

            // Check if mixed location cart is enabled
            $allow_mixed = isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['allow_mixed_location_cart']
                : 'off';

            if ($allow_mixed !== 'on') {
                return;
            }

            // Get user's selected location
            $selected_location = $this->get_current_location();

            if (empty($selected_location) || $selected_location === 'all-products') {
                return;
            }

            // Get transfer costs settings
            $options = get_option('mulopimfwc_display_options', []);
            $transfer_costs = isset($options['inter_location_transfer_costs']) && mulopimfwc_premium_feature()
                ? $options['inter_location_transfer_costs']
                : [];

            if (empty($transfer_costs)) {
                return;
            }

            // Get selected location term
            $destination_term = get_term_by('slug', $selected_location, 'mulopimfwc_store_location');
            if (!$destination_term || is_wp_error($destination_term)) {
                return;
            }

            $destination_slug = $destination_term->slug;
            $has_transfers = false;

            // Get cart items grouped by location
            $items_by_location = $this->get_cart_items_by_location();

            // Check if there are any transfer costs
            foreach ($items_by_location as $location_data) {
                $source_slug = $location_data['location_slug'];

                if ($source_slug === $destination_slug || $source_slug === 'unknown') {
                    continue;
                }

                $cost_key = $source_slug . '_to_' . $destination_slug;

                if (isset($transfer_costs[$cost_key]) && floatval($transfer_costs[$cost_key]) > 0) {
                    $has_transfers = true;
                    break;
                }
            }

            if (!$has_transfers) {
                return;
            }

        ?>
            <div class="mulopimfwc-transfer-cost-notice woocommerce-info">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4z" fill="currentColor" />
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="currentColor" />
                    </svg>
                    <div>
                        <strong><?php esc_html_e('Transfer Costs Applied', 'multi-location-product-and-inventory-management'); ?></strong>
                        <p style="margin: 5px 0 0 0; font-size: 13px;">
                            <?php
                            echo sprintf(
                                esc_html__('Your order includes products from multiple locations. Transfer costs to %s have been added to your total.', 'multi-location-product-and-inventory-management'),
                                '<strong>' . esc_html($destination_term->name) . '</strong>'
                            );
                            ?>
                        </p>
                    </div>
                </div>
            </div>
        <?php
        }

        /**
         * Add location data to cart item when product is added
         */

        public function add_location_to_cart_item($cart_item_data, $product_id, $variation_id)
        {
            // Always add location data to cart items for proper price and stock management
            // Get current selected location
            $location = $this->get_current_location();

            if (!empty($location) && $location !== 'all-products') {
                // Add location to cart item data
                $cart_item_data['mulopimfwc_location'] = $location;

                // Get location term for display name
                $location_term = get_term_by('slug', $location, 'mulopimfwc_store_location');
                if ($location_term && !is_wp_error($location_term)) {
                    $cart_item_data['mulopimfwc_location_name'] = $location_term->name;
                }
            }

            return $cart_item_data;
        }

        /**
         * Display location information in cart
         */

        public function display_location_in_cart($item_data, $cart_item)
        {
            global $mulopimfwc_options;

            // Check if cart grouping is enabled
            $group_cart = isset($mulopimfwc_options['group_cart_by_location']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['group_cart_by_location']
                : 'off';

            // Always show location information when available
            // Check if location data exists
            if (isset($cart_item['mulopimfwc_location_name']) && ($group_cart !== 'on' || is_cart())) {
                $item_data[] = array(
                    'key'     => __('Location', 'multi-location-product-and-inventory-management'),
                    'value'   => esc_html($cart_item['mulopimfwc_location_name']),
                    'display' => '',
                );
            }

            return $item_data;
        }

        /**
         * Save location data to order item meta
         */

        public function save_location_to_order_item($item, $cart_item_key, $values, $order)
        {
            global $mulopimfwc_options;

            // Check if mixed location cart is enabled
            $allow_mixed = isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['allow_mixed_location_cart']
                : 'off';

            // Always save location data if available, regardless of mixed cart setting
            // This ensures proper stock management and price tracking
            if (isset($values['mulopimfwc_location'])) {
                $item->add_meta_data('_mulopimfwc_location', $values['mulopimfwc_location'], true);
            }

            if (isset($values['mulopimfwc_location_name'])) {
                $item->add_meta_data(
                    __('Store Location', 'multi-location-product-and-inventory-management'),
                    $values['mulopimfwc_location_name'],
                    true
                );
            }
        }

        /**
         * Display location in order items (admin)
         */

        public function display_location_in_order_items($item_id, $item, $product)
        {
            // Always show location information when available
            // Get location from order item meta
            $location = $item->get_meta('_mulopimfwc_location');

            if (!empty($location)) {
                $location_term = get_term_by('slug', $location, 'mulopimfwc_store_location');
                if ($location_term && !is_wp_error($location_term)) {
                    echo '<div class="mulopimfwc-order-item-location">';
                    echo '<strong>' . esc_html__('Location:', 'multi-location-product-and-inventory-management') . '</strong> ';
                    echo esc_html($location_term->name);
                    echo '</div>';
                }
            }
        }

        /**
         * Validate cart items when location changes (with mixed cart enabled)
         */

        public function validate_mixed_cart_locations()
        {
            global $mulopimfwc_options;

            // Check if mixed location cart is enabled
            $allow_mixed = isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['allow_mixed_location_cart']
                : 'off';

            if ($allow_mixed !== 'on') {
                return;
            }

            // Validate each cart item still belongs to its stored location
            foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                if (isset($cart_item['mulopimfwc_location'])) {
                    $product_id = $cart_item['product_id'];
                    $stored_location = $cart_item['mulopimfwc_location'];

                    // Check if product still belongs to stored location
                    $terms = wp_get_object_terms($product_id, 'mulopimfwc_store_location', ['fields' => 'slugs']);

                    if (is_wp_error($terms) || !in_array($stored_location, $terms)) {
                        // Product no longer available at stored location
                        $product = wc_get_product($product_id);
                        wc_add_notice(
                            sprintf(
                                __(
                                    '"%s" is no longer available at %s location and has been removed from your cart.',
                                    'multi-location-product-and-inventory-management'
                                ),
                                $product->get_name(),
                                $cart_item['mulopimfwc_location_name']
                            ),
                            'error'
                        );
                        WC()->cart->remove_cart_item($cart_item_key);
                    }
                }
            }
        }

        /**
         * Get cart items grouped by location
         */
        public function get_cart_items_by_location()
        {
            global $mulopimfwc_options;

            // Check if mixed location cart is enabled
            $allow_mixed = isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['allow_mixed_location_cart']
                : 'off';

            if ($allow_mixed !== 'on') {
                return array();
            }

            $items_by_location = array();

            foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                $location = isset($cart_item['mulopimfwc_location'])
                    ? $cart_item['mulopimfwc_location']
                    : 'unknown';

                if (!isset($items_by_location[$location])) {
                    $items_by_location[$location] = array(
                        'location_name' => isset($cart_item['mulopimfwc_location_name'])
                            ? $cart_item['mulopimfwc_location_name']
                            : __('Unknown Location', 'multi-location-product-and-inventory-management'),
                        'location_slug' => $location,
                        'items' => array()
                    );
                }

                $items_by_location[$location]['items'][] = array_merge($cart_item, ['cart_item_key' => $cart_item_key]);
            }

            return $items_by_location;
        }

        /**
         * Get cart items grouped by location for grouping display
         */
        public function get_cart_items_by_location_for_grouping()
        {
            // Return cached result if available
            if ($this->cart_items_cache !== null) {
                return $this->cart_items_cache;
            }

            if (!$this->should_apply_cart_grouping()) {
                return array();
            }

            $items_by_location = array();

            // Get cart once and cache it
            $cart_contents = WC()->cart->get_cart();

            if (empty($cart_contents)) {
                $this->cart_items_cache = array();
                return array();
            }

            foreach ($cart_contents as $cart_item_key => $cart_item) {
                $location = isset($cart_item['mulopimfwc_location'])
                    ? $cart_item['mulopimfwc_location']
                    : 'unknown';

                if (!isset($items_by_location[$location])) {
                    $items_by_location[$location] = array(
                        'location_name' => isset($cart_item['mulopimfwc_location_name'])
                            ? $cart_item['mulopimfwc_location_name']
                            : __('Unknown Location', 'multi-location-product-and-inventory-management'),
                        'location_slug' => $location,
                        'items' => array()
                    );
                }

                $items_by_location[$location]['items'][] = array_merge($cart_item, ['cart_item_key' => $cart_item_key]);
            }

            // Cache the result
            $this->cart_items_cache = $items_by_location;
            return $items_by_location;
        }

        /**
         * Display cart items grouped by location
         */

        public function display_cart_location_summary()
        {
            global $mulopimfwc_options;

            // Check if mixed location cart is enabled
            $allow_mixed = isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['allow_mixed_location_cart']
                : 'off';

            if ($allow_mixed !== 'on') {
                return;
            }

            $items_by_location = $this->get_cart_items_by_location();

            if (count($items_by_location) > 1) {
                echo '<div class="mulopimfwc-cart-location-notice woocommerce-info">';
                echo '<strong>' . esc_html__('Your cart contains items from multiple locations:', 'multi-location-product-and-inventory-management') . '</strong><br>';

                foreach ($items_by_location as $location => $data) {
                    $item_count = count($data['items']);
                    echo sprintf(
                        esc_html__('%s: %d item(s)', 'multi-location-product-and-inventory-management'),
                        '<strong>' . esc_html($data['location_name']) . '</strong>',
                        $item_count
                    ) . '<br>';
                }

                echo '</div>';
            }
        }

        /**
         * Check if cart grouping is enabled and override cart display
         */
        public function maybe_override_cart_display()
        {
            // Check if this is actually the cart page
            if (!function_exists('is_cart') || !is_cart()) {
                return;
            }

            if (!$this->should_apply_cart_grouping()) {
                return;
            }

            $items_by_location = $this->get_cart_items_by_location_for_grouping();

            // Only group if there are multiple locations
            if (count($items_by_location) <= 1) {
                return;
            }

            // Start buffering ONLY for the cart table
            ob_start();
        }


        /**
         * Restore cart display after grouping
         */
        public function maybe_restore_cart_display()
        {
            // Check if this is actually the cart page
            if (!function_exists('is_cart') || !is_cart()) {
                return;
            }

            if (!$this->should_apply_cart_grouping()) {
                return;
            }

            $items_by_location = $this->get_cart_items_by_location_for_grouping();

            // Only group if there are multiple locations
            if (count($items_by_location) <= 1) {
                return;
            }

            // Clear buffer and display grouped cart
            ob_end_clean();
            $this->display_grouped_cart();
        }

        /**
         * Check if cart grouping should be applied
         */
        private function should_apply_cart_grouping()
        {
            // Return cached result if available
            if ($this->should_group_cache !== null) {
                return $this->should_group_cache;
            }

            global $mulopimfwc_options;

            // Check if cart grouping is enabled
            $group_cart = isset($mulopimfwc_options['group_cart_by_location']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['group_cart_by_location']
                : 'off';

            if ($group_cart !== 'on') {
                $this->should_group_cache = false;
                return false;
            }

            // Check if mixed location cart is enabled
            $allow_mixed = isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['allow_mixed_location_cart']
                : 'off';

            $this->should_group_cache = ($allow_mixed === 'on');
            return $this->should_group_cache;
        }

        /**
         * Display grouped mini cart
         */
        public function display_grouped_mini_cart()
        {
            $items_by_location = $this->get_cart_items_by_location_for_grouping();

            if (empty($items_by_location)) {
                // Fallback to default mini cart display
                wc_get_template('cart/mini-cart.php');
                return;
            }

            // If only one location, display normally
            if (count($items_by_location) === 1) {
                wc_get_template('cart/mini-cart.php');
                return;
            }

            // Display grouped mini cart
        ?>
            <div class="mulopimfwc-grouped-mini-cart">
                <?php foreach ($items_by_location as $location_data): ?>
                    <div class="mulopimfwc-mini-location-group">
                        <div class="mulopimfwc-mini-location-header">
                            <div class="mulopimfwc-mini-location-icon">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="currentColor" />
                                </svg>
                            </div>
                            <span class="mulopimfwc-mini-location-name"><?php echo esc_html($location_data['location_name']); ?></span>
                        </div>

                        <div class="mulopimfwc-mini-location-items">
                            <?php foreach ($location_data['items'] as $cart_item): ?>
                                <?php
                                $product = $cart_item['data'];
                                $product_id = $cart_item['product_id'];
                                $variation_id = $cart_item['variation_id'];
                                $cart_item_key = $cart_item['cart_item_key'];

                                if (!$product || !$product->exists() || $cart_item['quantity'] <= 0) {
                                    continue;
                                }
                                ?>
                                <div class="woocommerce-mini-cart-item mini_cart_item">
                                    <?php
                                    echo apply_filters('woocommerce_cart_item_remove_link', sprintf(
                                        '<a href="%s" class="remove remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s">&times;</a>',
                                        esc_url(wc_get_cart_remove_url($cart_item_key)),
                                        esc_html__('Remove this item', 'woocommerce'),
                                        $product_id,
                                        $cart_item_key,
                                        $product->get_sku()
                                    ), $cart_item_key);
                                    ?>

                                    <?php
                                    $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $product->get_image(), $cart_item, $cart_item_key);
                                    if (!$product->is_visible()) {
                                        echo $thumbnail;
                                    } else {
                                        printf('<a href="%s">%s</a>', esc_url($product->get_permalink($cart_item)), $thumbnail);
                                    }
                                    ?>

                                    <div class="mini_cart_item_details">
                                        <?php
                                        if (!$product->is_visible()) {
                                            echo wp_kses_post(apply_filters('woocommerce_cart_item_name', $product->get_name(), $cart_item, $cart_item_key) . '&nbsp;');
                                        } else {
                                            echo wp_kses_post(apply_filters('woocommerce_cart_item_name', sprintf('<a href="%s">%s</a>', esc_url($product->get_permalink($cart_item)), $product->get_name()), $cart_item, $cart_item_key));
                                        }

                                        do_action('woocommerce_after_cart_item_name', $cart_item, $cart_item_key);

                                        // Meta data
                                        echo wc_get_formatted_cart_item_data($cart_item);

                                        // Backorder notification
                                        if ($product->backorders_require_notification() && $product->is_on_backorder($cart_item['quantity'])) {
                                            echo wp_kses_post(apply_filters('woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__('Available on backorder', 'woocommerce') . '</p>', $product_id));
                                        }
                                        ?>

                                        <div class="mini_cart_item_quantity">
                                            <?php echo apply_filters('woocommerce_widget_cart_item_quantity', '<span class="quantity">' . sprintf('%s &times; %s', $cart_item['quantity'], $product->get_price_html()) . '</span>', $cart_item, $cart_item_key); ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php
        }

        /**
         * Override checkout cart display
         */
        public function maybe_override_checkout_cart_display()
        {
            // Check if this is actually the checkout page
            if (!function_exists('is_checkout') || !is_checkout()) {
                return;
            }

            if (!$this->should_apply_cart_grouping()) {
                return;
            }

            $items_by_location = $this->get_cart_items_by_location_for_grouping();

            if (count($items_by_location) <= 1) {
                return;
            }

            ob_start();
        }

        /**
         * Restore checkout cart display
         */
        public function maybe_restore_checkout_cart_display()
        {
            // Check if this is actually the checkout page
            if (!function_exists('is_checkout') || !is_checkout()) {
                return;
            }

            if (!$this->should_apply_cart_grouping()) {
                return;
            }

            $items_by_location = $this->get_cart_items_by_location_for_grouping();

            if (count($items_by_location) <= 1) {
                return;
            }

            ob_end_clean();
            $this->display_grouped_checkout_cart();
        }

        /**
         * Display grouped checkout cart
         */
        public function display_grouped_checkout_cart()
        {
            $items_by_location = $this->get_cart_items_by_location_for_grouping();

            if (empty($items_by_location)) {
                // Fallback to default checkout cart display
                wc_get_template('checkout/review-order.php');
                return;
            }

            // If only one location, display normally
            if (count($items_by_location) === 1) {
                wc_get_template('checkout/review-order.php');
                return;
            }

            // Display grouped checkout cart
        ?>
            <div class="mulopimfwc-grouped-checkout-cart">
                <?php foreach ($items_by_location as $location_data): ?>
                    <div class="mulopimfwc-location-group">
                        <div class="mulopimfwc-location-header">
                            <div class="mulopimfwc-location-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="currentColor" />
                                </svg>
                            </div>
                            <h3 class="mulopimfwc-location-name"><?php echo esc_html($location_data['location_name']); ?></h3>
                        </div>

                        <div class="mulopimfwc-location-items">
                            <table class="shop_table woocommerce-checkout-review-order-table" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th class="product-name"><?php esc_html_e('Product', 'woocommerce'); ?></th>
                                        <th class="product-total"><?php esc_html_e('Subtotal', 'woocommerce'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($location_data['items'] as $cart_item): ?>
                                        <?php
                                        $product = $cart_item['data'];
                                        $product_id = $cart_item['product_id'];
                                        $variation_id = $cart_item['variation_id'];
                                        $cart_item_key = $cart_item['cart_item_key'];

                                        if (!$product || !$product->exists() || $cart_item['quantity'] <= 0) {
                                            continue;
                                        }
                                        ?>
                                        <tr class="cart_item">
                                            <td class="product-name">
                                                <?php
                                                if (!$product->is_visible()) {
                                                    echo wp_kses_post(apply_filters('woocommerce_cart_item_name', $product->get_name(), $cart_item, $cart_item_key) . '&nbsp;');
                                                } else {
                                                    echo wp_kses_post(apply_filters('woocommerce_cart_item_name', sprintf('<a href="%s">%s</a>', esc_url($product->get_permalink($cart_item)), $product->get_name()), $cart_item, $cart_item_key));
                                                }

                                                do_action('woocommerce_after_cart_item_name', $cart_item, $cart_item_key);

                                                // Meta data
                                                echo wc_get_formatted_cart_item_data($cart_item);

                                                // Backorder notification
                                                if ($product->backorders_require_notification() && $product->is_on_backorder($cart_item['quantity'])) {
                                                    echo wp_kses_post(apply_filters('woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__('Available on backorder', 'woocommerce') . '</p>', $product_id));
                                                }
                                                ?>
                                                <strong class="product-quantity"><?php echo apply_filters('woocommerce_checkout_cart_item_quantity', '&nbsp;&times;&nbsp;' . $cart_item['quantity'], $cart_item, $cart_item_key); ?></strong>
                                            </td>
                                            <td class="product-total">
                                                <?php
                                                echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($product, $cart_item['quantity']), $cart_item, $cart_item_key);
                                                ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php
        }

        /**
         * Display cart grouped by location
         */
        public function display_grouped_cart()
        {
            $items_by_location = $this->get_cart_items_by_location_for_grouping();

            if (empty($items_by_location)) {
                // Fallback to default cart display
                wc_get_template('cart/cart.php');
                return;
            }

            // If only one location, display normally
            if (count($items_by_location) === 1) {
                wc_get_template('cart/cart.php');
                return;
            }

            // Display grouped cart
        ?>
            <form class="woocommerce-cart-form" action="<?php echo esc_url(wc_get_cart_url()); ?>" method="post">
                <?php wp_nonce_field('woocommerce-cart', 'woocommerce-cart-nonce'); ?>
                <div class="mulopimfwc-grouped-cart">
                    <?php foreach ($items_by_location as $location_data): ?>
                        <div class="mulopimfwc-location-group">
                            <div class="mulopimfwc-location-header">
                                <div class="mulopimfwc-location-icon">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="currentColor" />
                                    </svg>
                                </div>
                                <h3 class="mulopimfwc-location-name"><?php echo esc_html($location_data['location_name']); ?></h3>
                            </div>

                            <div class="mulopimfwc-location-items">
                                <table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th class="product-remove">&nbsp;</th>
                                            <th class="product-thumbnail">&nbsp;</th>
                                            <th class="product-name"><?php esc_html_e('Product', 'woocommerce'); ?></th>
                                            <th class="product-price"><?php esc_html_e('Price', 'woocommerce'); ?></th>
                                            <th class="product-quantity"><?php esc_html_e('Quantity', 'woocommerce'); ?></th>
                                            <th class="product-subtotal"><?php esc_html_e('Subtotal', 'woocommerce'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($location_data['items'] as $cart_item): ?>
                                            <?php
                                            $product = $cart_item['data'];
                                            $product_id = $cart_item['product_id'];
                                            $variation_id = $cart_item['variation_id'];
                                            $cart_item_key = $cart_item['cart_item_key'];

                                            if (!$product || !$product->exists() || $cart_item['quantity'] <= 0) {
                                                continue;
                                            }
                                            ?>
                                            <tr class="woocommerce-cart-form__cart-item cart_item">
                                                <td class="product-remove">
                                                    <?php
                                                    echo apply_filters('woocommerce_cart_item_remove_link', sprintf(
                                                        '<a href="%s" class="remove" aria-label="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
                                                        esc_url(wc_get_cart_remove_url($cart_item_key)),
                                                        esc_html__('Remove this item', 'woocommerce'),
                                                        $product_id,
                                                        $product->get_sku()
                                                    ), $cart_item_key);
                                                    ?>
                                                </td>
                                                <td class="product-thumbnail">
                                                    <?php
                                                    $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $product->get_image(), $cart_item, $cart_item_key);
                                                    if (!$product->is_visible()) {
                                                        echo $thumbnail;
                                                    } else {
                                                        printf('<a href="%s">%s</a>', esc_url($product->get_permalink($cart_item)), $thumbnail);
                                                    }
                                                    ?>
                                                </td>
                                                <td class="product-name" data-title="<?php esc_attr_e('Product', 'woocommerce'); ?>">
                                                    <?php
                                                    if (!$product->is_visible()) {
                                                        echo wp_kses_post(apply_filters('woocommerce_cart_item_name', $product->get_name(), $cart_item, $cart_item_key) . '&nbsp;');
                                                    } else {
                                                        echo wp_kses_post(apply_filters('woocommerce_cart_item_name', sprintf('<a href="%s">%s</a>', esc_url($product->get_permalink($cart_item)), $product->get_name()), $cart_item, $cart_item_key));
                                                    }

                                                    do_action('woocommerce_after_cart_item_name', $cart_item, $cart_item_key);

                                                    // Meta data
                                                    echo wc_get_formatted_cart_item_data($cart_item);

                                                    // Backorder notification
                                                    if ($product->backorders_require_notification() && $product->is_on_backorder($cart_item['quantity'])) {
                                                        echo wp_kses_post(apply_filters('woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__('Available on backorder', 'woocommerce') . '</p>', $product_id));
                                                    }
                                                    ?>
                                                </td>
                                                <td class="product-price" data-title="<?php esc_attr_e('Price', 'woocommerce'); ?>">
                                                    <?php
                                                    echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($product), $cart_item, $cart_item_key);
                                                    ?>
                                                </td>
                                                <td class="product-quantity" data-title="<?php esc_attr_e('Quantity', 'woocommerce'); ?>">
                                                    <?php
                                                    if ($product->is_sold_individually()) {
                                                        $product_quantity = sprintf('1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key);
                                                    } else {
                                                        $product_quantity = woocommerce_quantity_input(
                                                            array(
                                                                'input_name'   => "cart[{$cart_item_key}][qty]",
                                                                'input_value'  => $cart_item['quantity'],
                                                                'max_value'    => $product->get_max_purchase_quantity(),
                                                                'min_value'    => '0',
                                                                'product_name' => $product->get_name(),
                                                            ),
                                                            $product,
                                                            false
                                                        );
                                                    }

                                                    echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item);
                                                    ?>
                                                </td>
                                                <td class="product-subtotal" data-title="<?php esc_attr_e('Subtotal', 'woocommerce'); ?>">
                                                    <?php
                                                    echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($product, $cart_item['quantity']), $cart_item, $cart_item_key);
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="actions">
                    <button type="submit" class="button" name="update_cart" value="<?php esc_attr_e('Update cart', 'woocommerce'); ?>"><?php esc_html_e('Update cart', 'woocommerce'); ?></button>
                    <?php do_action('woocommerce_cart_actions'); ?>
                </div>
            </form>
        <?php
        }

        /**
         * Display grouped cart block
         */
        public function display_grouped_cart_block()
        {
            $items_by_location = $this->get_cart_items_by_location_for_grouping();

            if (empty($items_by_location)) {
                return;
            }

            // If only one location, don't group
            if (count($items_by_location) === 1) {
                return;
            }

        ?>
            <div class="mulopimfwc-grouped-cart-block">
                <?php foreach ($items_by_location as $location_data): ?>
                    <div class="mulopimfwc-location-group">
                        <div class="mulopimfwc-location-header">
                            <div class="mulopimfwc-location-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="currentColor" />
                                </svg>
                            </div>
                            <h3 class="mulopimfwc-location-name"><?php echo esc_html($location_data['location_name']); ?></h3>
                        </div>

                        <div class="mulopimfwc-location-items">
                            <?php foreach ($location_data['items'] as $cart_item): ?>
                                <?php
                                $product = $cart_item['data'];
                                $product_id = $cart_item['product_id'];
                                $variation_id = $cart_item['variation_id'];
                                $cart_item_key = $cart_item['cart_item_key'];

                                if (!$product || !$product->exists() || $cart_item['quantity'] <= 0) {
                                    continue;
                                }
                                ?>
                                <div class="woocommerce-cart-form__cart-item cart_item">
                                    <div class="product-remove">
                                        <?php
                                        echo apply_filters('woocommerce_cart_item_remove_link', sprintf(
                                            '<a href="%s" class="remove" aria-label="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
                                            esc_url(wc_get_cart_remove_url($cart_item_key)),
                                            esc_html__('Remove this item', 'woocommerce'),
                                            $product_id,
                                            $product->get_sku()
                                        ), $cart_item_key);
                                        ?>
                                    </div>
                                    <div class="product-thumbnail">
                                        <?php
                                        $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $product->get_image(), $cart_item, $cart_item_key);
                                        if (!$product->is_visible()) {
                                            echo $thumbnail;
                                        } else {
                                            printf('<a href="%s">%s</a>', esc_url($product->get_permalink($cart_item)), $thumbnail);
                                        }
                                        ?>
                                    </div>
                                    <div class="product-name">
                                        <?php
                                        if (!$product->is_visible()) {
                                            echo wp_kses_post(apply_filters('woocommerce_cart_item_name', $product->get_name(), $cart_item, $cart_item_key) . '&nbsp;');
                                        } else {
                                            echo wp_kses_post(apply_filters('woocommerce_cart_item_name', sprintf('<a href="%s">%s</a>', esc_url($product->get_permalink($cart_item)), $product->get_name()), $cart_item, $cart_item_key));
                                        }

                                        do_action('woocommerce_after_cart_item_name', $cart_item, $cart_item_key);

                                        // Meta data
                                        echo wc_get_formatted_cart_item_data($cart_item);

                                        // Backorder notification
                                        if ($product->backorders_require_notification() && $product->is_on_backorder($cart_item['quantity'])) {
                                            echo wp_kses_post(apply_filters('woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__('Available on backorder', 'woocommerce') . '</p>', $product_id));
                                        }
                                        ?>
                                    </div>
                                    <div class="product-price">
                                        <?php
                                        echo apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($product), $cart_item, $cart_item_key);
                                        ?>
                                    </div>
                                    <div class="product-quantity">
                                        <?php
                                        if ($product->is_sold_individually()) {
                                            $product_quantity = sprintf('1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key);
                                        } else {
                                            $product_quantity = woocommerce_quantity_input(
                                                array(
                                                    'input_name'   => "cart[{$cart_item_key}][qty]",
                                                    'input_value'  => $cart_item['quantity'],
                                                    'max_value'    => $product->get_max_purchase_quantity(),
                                                    'min_value'    => '0',
                                                    'product_name' => $product->get_name(),
                                                ),
                                                $product,
                                                false
                                            );
                                        }

                                        echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item);
                                        ?>
                                    </div>
                                    <div class="product-subtotal">
                                        <?php
                                        echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($product, $cart_item['quantity']), $cart_item, $cart_item_key);
                                        ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
<?php
        }

        /**
         * Get available locations for a product via AJAX
         */
        public function cymulopimfwc_get_available_locations()
        {
            global $mulopimfwc_locations;
            // Check nonce
            check_ajax_referer('location_wise_products_nonce', 'security');

            // Check permissions
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'multi-location-product-and-inventory-management')]);
            }

            // Get product ID
            $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
            $location_selected = wp_get_object_terms($product_id, 'mulopimfwc_store_location', array('fields' => 'slugs'));
            if (!$product_id) {
                wp_send_json_error(['message' => __('Invalid product ID.', 'multi-location-product-and-inventory-management')]);
            }

            if (is_wp_error($mulopimfwc_locations)) {
                wp_send_json_error(['message' => $mulopimfwc_locations->get_error_message()]);
            }

            // Format locations for output
            $location_data = [];
            foreach ($mulopimfwc_locations as $location) {
                $location_data[] = [
                    'id' => $location->term_id,
                    'name' => $location->name,
                    'parent' => $location->parent,
                    'selected' => in_array($location->slug, $location_selected),
                ];
            }

            wp_send_json_success(['locations' => $location_data]);
        }

        /**
         * Save product locations via AJAX
         */
        public function cymulopimfwc_save_product_locations()
        {
            // Check nonce
            check_ajax_referer('location_wise_products_nonce', 'security');

            // Check permissions
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'multi-location-product-and-inventory-management')]);
            }

            // Get product ID and location IDs
            $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
            $location_ids = isset($_POST['location_ids']) ? array_map('intval', (array) $_POST['location_ids']) : [];

            if (!$product_id) {
                wp_send_json_error(['message' => __('Invalid product ID.', 'multi-location-product-and-inventory-management')]);
            }

            // Set product locations
            wp_set_object_terms($product_id, $location_ids, 'mulopimfwc_store_location');

            wp_send_json_success([
                'message' => __('Product locations saved successfully.', 'multi-location-product-and-inventory-management'),
            ]);
        }

        /**
         * Update product location status via AJAX
         */
        public function cymulopimfwc_update_product_location_status()
        {
            // Check nonce
            check_ajax_referer('location_wise_products_nonce', 'security');

            // Check permissions
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(['message' => __('You do not have permission to perform this action.', 'multi-location-product-and-inventory-management')]);
            }

            // Get parameters
            $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
            $location_id = isset($_POST['location_id']) ? intval($_POST['location_id']) : 0;
            $action = isset($_POST['status_action']) ? sanitize_text_field(wp_unslash($_POST['status_action'])) : '';

            if (!$product_id || !$location_id || !in_array($action, ['activate', 'deactivate'])) {
                wp_send_json_error(['message' => __('Invalid parameters.', 'multi-location-product-and-inventory-management')]);
            }

            // Update location status
            if ($action === 'activate') {
                // Activate location - remove disabled meta
                delete_post_meta($product_id, '_location_disabled_' . $location_id);
                $message = __('Location activated successfully.', 'multi-location-product-and-inventory-management');
            } else {
                // Deactivate location - add disabled meta
                update_post_meta($product_id, '_location_disabled_' . $location_id, 1);
                $message = __('Location deactivated successfully.', 'multi-location-product-and-inventory-management');
            }

            wp_send_json_success(['message' => $message]);
        }
        /**
         * Enqueue admin scripts
         */
        public function cymulopimfwc_enqueue_admin_scripts($hook)
        {
            // Only on product location page
            // if ($hook !== 'multi-location-product-and-inventory-management-settings') {
            //     return;
            // }

            wp_enqueue_script(
                'mulopimfwc-multi-location-product-and-inventory-managements-admin',
                plugin_dir_url(__FILE__) . 'assets/js/admin.js',
                ['jquery'],
                '1.0.3.20',
                true
            );

            wp_localize_script('mulopimfwc-multi-location-product-and-inventory-managements-admin', 'mulopimfwc_locationWiseProducts', [
                'nonce' => wp_create_nonce('location_wise_products_nonce'),
                'i18n' => [
                    'activate' => __('Activate', 'multi-location-product-and-inventory-management'),
                    'deactivate' => __('Deactivate', 'multi-location-product-and-inventory-management'),
                    'selectLocations' => __('Select Locations', 'multi-location-product-and-inventory-management'),
                    'saveLocations' => __('Save Locations', 'multi-location-product-and-inventory-management'),
                    'ajaxError' => __('An error occurred. Please try again.', 'multi-location-product-and-inventory-management'),
                ],
            ]);

            // Add modal styles
            wp_enqueue_style(
                'mulopimfwc-multi-location-product-and-inventory-managements-admin',
                plugin_dir_url(__FILE__) . 'assets/css/admin.css',
                [],
                '1.0.3.20'
            );
        }

        /**
         * Save location from cookie to order meta
         *
         * @param WC_Order $order Order object
         * @param array $data Order data
         */
        public function save_location_to_order_meta($order_id)
        {
            $location = isset($_COOKIE['mulopimfwc_store_location']) ? sanitize_text_field(wp_unslash($_COOKIE['mulopimfwc_store_location'])) : '';

            if (!empty($location)) {
                $order = wc_get_order($order_id);
                if ($order) {
                    $order->update_meta_data('_store_location', $location);
                    $order->save();
                }
            }
        }
        private function get_all_store_locations()
        {
            global $mulopimfwc_locations;

            if (is_wp_error($mulopimfwc_locations)) {
                return array();
            }

            return wp_list_pluck($mulopimfwc_locations, 'slug');
        }

        /**
         * Add filter dropdown in the WooCommerce orders list table
         */
        public function add_store_location_filter()
        {

            $locations = $this->get_all_store_locations();

            if (!isset($_GET['store_location_filter_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['store_location_filter_nonce'])), 'store_location_filter_nonce')) {
                $selected_location = '';
            } else {
                $selected_location = isset($_GET['mulopimfwc_store_location']) ? sanitize_text_field(wp_unslash($_GET['mulopimfwc_store_location'])) : '';
            }

            // add nonce for security
            wp_nonce_field('store_location_filter_nonce', 'store_location_filter_nonce');

            echo '<select name="mulopimfwc_store_location" id="mulopimfwc_store_location">';
            echo '<option value="">' . esc_html__('All Locations', 'multi-location-product-and-inventory-management') . '</option>';

            foreach ($locations as $location) {
                $selected = ($location === $selected_location) ? 'selected' : '';
                echo '<option value="' . esc_attr($location) . '" ' . esc_attr($selected) . '>' . esc_html(ucfirst(strtolower($location))) . '</option>';
            }

            echo '</select>';
        }

        /**
         * Filter orders by store location
         * 
         * @param array $query_args Query arguments
         * @return array Modified query arguments
         */
        public function filter_orders_by_location($query_args)
        {
            if (!isset($_GET['store_location_filter_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['store_location_filter_nonce'])), 'store_location_filter_nonce')) {
                $selected_location = '';
            } else {
                $selected_location = isset($_GET['mulopimfwc_store_location']) ? sanitize_text_field(wp_unslash($_GET['mulopimfwc_store_location'])) : '';
            }

            if (!empty($selected_location)) {
                $query_args['meta_query'][] = [
                    'key' => '_store_location',
                    'value' => $selected_location,
                    'compare' => '='
                ];
            }

            return $query_args;
        }

        // add_settings_link
        public function add_settings_link($links)
        {
            if (!is_array($links)) {
                $links = [];
            }
            $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=multi-location-product-and-inventory-management')) . '">' . esc_html__('Settings', 'multi-location-product-and-inventory-management') . '</a>';
            $links[] = $settings_link;
            return $links;
        }

        public function enqueue_scripts()
        {
            global $mulopimfwc_options;

            $cookie_expiry = isset($mulopimfwc_options["location_cookie_expiry"]) && is_numeric($mulopimfwc_options["location_cookie_expiry"])
                ? (int)$mulopimfwc_options["location_cookie_expiry"]
                : 30;

            wp_enqueue_style('mulopimfwc_style', plugins_url('assets/css/style.css', __FILE__), [], '1.0.3.20');
            wp_enqueue_style('mulopimfwc_select2', plugins_url('assets/css/select2.min.css', __FILE__), [], '4.1.0');
            wp_enqueue_script('mulopimfwc_script', plugins_url('assets/js/script.js', __FILE__), ['jquery'], '1.0.3.20', true);
            wp_enqueue_script('mulopimfwc_select2', plugins_url('assets/js/select2.min.js', __FILE__), ['jquery'], '4.1.0', true);

            // Check if cart grouping is enabled
            $group_cart = isset($mulopimfwc_options['group_cart_by_location']) && mulopimfwc_premium_feature()
                ? $mulopimfwc_options['group_cart_by_location']
                : 'off';

            // Always show location information when available
            // Check if location data exists
            if ($group_cart === 'on') {
                // Cart Block grouping (JS + CSS)
                wp_enqueue_script(
                    'mulopimfwc-cart-block-grouping',
                    plugins_url('assets/js/cart-block-grouping.js', __FILE__),
                    array('wp-hooks'), // important
                    '1.0.4',
                    true
                );

                wp_add_inline_style('mulopimfwc_style', '.wc-block-components-product-details__location{display:none !important;}');
            }


            wp_localize_script('mulopimfwc_script', 'mulopimfwc_locationWiseProducts', [
                'cartHasProducts' => !WC()->cart->is_empty(),
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'location_change_notification' => isset($mulopimfwc_options["location_change_notification"]),
                'nonce' => wp_create_nonce('multi-location-product-and-inventory-management'),
                'cookie_expiry' => $cookie_expiry,
                'allow_mixed_in_cart' => isset($mulopimfwc_options['allow_mixed_location_cart']) && mulopimfwc_premium_feature()
                    ? $mulopimfwc_options['allow_mixed_location_cart']
                    : 'off',
                'location_notification_text' => isset($mulopimfwc_options['location_notification_text']) && mulopimfwc_premium_feature()
                    ? $mulopimfwc_options['location_notification_text']
                    : 'Do you want to change the store location? Your cart will be emptied.'
            ]);

            wp_enqueue_style('leaflet', 'https://unpkg.com/leaflet@1.7.1/dist/leaflet.css', array(), '1.7.1');
            wp_enqueue_script('leaflet', 'https://unpkg.com/leaflet@1.7.1/dist/leaflet.js', array('jquery'), '1.7.1', true);
        }

        private function get_current_location()
        {
            return isset($_COOKIE['mulopimfwc_store_location']) ? sanitize_text_field(wp_unslash($_COOKIE['mulopimfwc_store_location'])) : '';
        }

        public function filter_shortcode_products($query_args)
        {
            $location = $this->get_current_location();
            global $mulopimfwc_options;
            $enable_all_locations = isset($mulopimfwc_options['enable_all_locations']) ? $mulopimfwc_options['enable_all_locations'] : 'off';
            if (!$location || $location === 'all-products' || $enable_all_locations === 'on') {
                return $query_args;
            }

            // if (!isset($query_args['tax_query'])) {
            //     $query_args['tax_query'] = [];
            // }

            $query_args['tax_query'][] = [
                'taxonomy' => 'mulopimfwc_store_location',
                'field' => 'slug',
                'terms' => $location,
            ];

            return $query_args;
        }

        public function filter_widget_products($query_args)
        {
            return $this->filter_shortcode_products($query_args);
        }

        public function filter_related_products($args)
        {
            return $this->filter_shortcode_products($args);
        }

        public function clear_cart_on_location_change()
        {
            if (!isset($_POST['mulopimfwc_shortcode_selector_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mulopimfwc_shortcode_selector_nonce'])), 'mulopimfwc_shortcode_selector')) {
                return;
            }
            if (isset($_POST['clear_cart_on_store_change']) && $_POST['clear_cart_on_store_change'] == '1') {
                if (function_exists('WC')) {
                    WC()->cart->empty_cart();
                    WC()->session->set('cart', []);
                }
            }
        }

        public function location_selector_modal()
        {
            global $mulopimfwc_locations;
            $is_user_logged_in = is_user_logged_in();
            $current_user = wp_get_current_user();
            $is_admin_or_manager = in_array('administrator', $current_user->roles) || in_array('shop_manager', $current_user->roles);
            // mulopimfwc_display_options[show_popup_admin]
            $options = get_option('mulopimfwc_display_options', []);
            $show_popup_admin = isset($options['show_popup_admin']) ? $options['show_popup_admin'] : 'off';
            $selected_location = $this->get_current_location();
            $locationSelected = isset($_COOKIE['mulopimfwc_store_location']) ? sanitize_text_field(wp_unslash($_COOKIE['mulopimfwc_store_location'])) : '';
            $show_modal = $show_popup_admin === 'on' && empty($selected_location) ? true : (empty($selected_location) && !$is_admin_or_manager);

            $locations = $mulopimfwc_locations;



            include plugin_dir_path(__FILE__) . 'templates/modal.php';
        }

        public function location_selector_shortcode($atts)
        {
            global $mulopimfwc_locations;
            $atts = shortcode_atts([
                'title' => __('Select Store Location', 'multi-location-product-and-inventory-management'),
                'show_title' => 'on',
                'class' => '',
                'show_button' => '',
                'use_select2' => '',
                'herichical' => '',
                'show_count' => '',
                'enable_user_locations' => 'off', // New attribute
                'max_width' => '300',
                'multi_line' => 'off'
            ], $atts);

            $is_user_logged_in = is_user_logged_in();
            $current_user = wp_get_current_user();
            // mulopimfwc_display_options[show_all_products_admin]
            $options = get_option('mulopimfwc_display_options', []);
            $show_all_products_admin = isset($options['show_all_products_admin']) ? $options['show_all_products_admin'] : 'off';
            $is_admin_or_manager = in_array('administrator', $current_user->roles) || in_array('shop_manager', $current_user->roles);
            $selected_location = $this->get_current_location();

            $locations = $mulopimfwc_locations;

            ob_start();
            include plugin_dir_path(__FILE__) . 'templates/shortcode-selector.php';
            return ob_get_clean();
        }

        public function add_location_to_product_title($title, $post_id = 0)
        {
            if (!$post_id || get_post_type($post_id) !== 'product') {
                return $title;
            }
            return $this->get_title_with_location($title, $post_id);
        }

        public function add_location_to_wc_product_title($title, $product = null)
        {
            if (!$product) {
                return $title;
            }
            return $this->get_title_with_location($title, $product->get_id());
        }


        private function get_display_options()
        {
            $options = get_option('mulopimfwc_display_options', []);
            return $options;
        }

        private function get_title_with_location($title, $product_id)
        {
            $locations = get_the_terms($product_id, 'mulopimfwc_store_location');
            if (!$locations || is_wp_error($locations)) {
                return $title;
            }

            $options = $this->get_display_options();
            $enabled_pages = isset($options['enabled_pages']) ? $options['enabled_pages'] : ['shop', 'single', 'cart'];
            $should_display = false;

            // Check standard WooCommerce pages
            if (in_array('shop', $enabled_pages) && (is_shop() || is_product_category() || is_product_tag() || is_post_type_archive('product'))) {
                $should_display = true;
            } elseif (in_array('single', $enabled_pages) && is_singular('product')) {
                $should_display = true;
            } elseif (in_array('cart', $enabled_pages) && (is_cart() || is_checkout())) {
                $should_display = true;
            } elseif (in_array('search', $enabled_pages) && is_search()) {
                $should_display = true;
            } elseif (in_array('widgets', $enabled_pages) && (is_active_widget(false, false, 'woocommerce_products', true) || is_active_widget(false, false, 'woocommerce_recent_products', true))) {
                $should_display = true;
            } elseif (
                in_array('Shortcode', $enabled_pages) && !is_shop() && !is_product_category() && !is_product_tag() &&
                !is_product() && !is_cart() && !is_checkout() && !is_account_page() && !is_admin()
            ) {
                $should_display = true;
            }

            if (!$should_display) {
                return $title;
            }

            $location_names = [];
            foreach ($locations as $location) {
                $location_names[] = $location->name;
            }

            $location_text = count($location_names) === 1 ? $location_names[0] : implode(', ', $location_names);
            $separator = isset($options['separator']) ? $options['separator'] : ' - ';
            $format = isset($options['display_format']) ? $options['display_format'] : 'none';

            switch ($format) {
                case 'prepend':
                    return $location_text . $separator . $title;
                case 'brackets':
                    return $title . ' [' . $location_text . ']';
                case 'none':
                    return $title;
                case 'append':
                default:
                    return $title . $separator . $location_text;
            }
        }

        private function product_belongs_to_location($product_id)
        {
            $location = $this->get_current_location();
            global $mulopimfwc_options;
            $enable_all_locations = isset($mulopimfwc_options['enable_all_locations']) ? $mulopimfwc_options['enable_all_locations'] : 'off';

            if (!$location || $location === 'all-products') {
                return true;
            }

            $terms = wp_get_object_terms($product_id, 'mulopimfwc_store_location', ['fields' => 'slugs']);
            if (empty($terms) && $enable_all_locations === 'on') {
                return true; // Product is available in all locations
            }
            return (!is_wp_error($terms) && in_array($location, $terms));
        }

        public function filter_product_blocks($html, $data, $product)
        {
            if (!$this->product_belongs_to_location($product->get_id())) {
                return '';
            }
            return $html;
        }

        public function filter_ajax_searched_products($products)
        {
            $location = $this->get_current_location();
            global $mulopimfwc_options;
            $enable_all_locations = isset($mulopimfwc_options['enable_all_locations']) ? $mulopimfwc_options['enable_all_locations'] : 'off';

            if (!$location || $location === 'all-products') {
                return $products;
            }

            foreach ($products as $id => $product) {
                if (!$this->product_belongs_to_location($id)) {
                    unset($products[$id]);
                }
            }

            return $products;
        }

        public function filter_rest_api_products($args, $request)
        {
            $location = $this->get_current_location();

            if (!$location || $location === 'all-products') {
                return $args;
            }

            // if (!isset($args['tax_query'])) {
            //     $args['tax_query'] = [];
            // }

            $args['tax_query'][] = [
                'taxonomy' => 'mulopimfwc_store_location',
                'field' => 'slug',
                'terms' => $location,
            ];

            return $args;
        }

        public function modify_product_rest_response($response, $product, $request)
        {
            if (!$this->product_belongs_to_location($product->get_id())) {
                $data = $response->get_data();
                $data['hidden_by_location'] = true;
                $response->set_data($data);
            }
            return $response;
        }

        public function filter_cart_contents($cart_contents)
        {
            $location = $this->get_current_location();

            if (!$location || $location === 'all-products') {
                return $cart_contents;
            }

            foreach ($cart_contents as $key => $item) {
                if (!$this->product_belongs_to_location($item['product_id'])) {
                    $cart_contents[$key]['hidden_by_location'] = true;
                }
            }

            return $cart_contents;
        }

        public function filter_recently_viewed_products()
        {
            $location = $this->get_filtered_location('recently_viewed');

            if (!$location) {
                return;
            }

            $viewed_products = isset($_COOKIE['woocommerce_recently_viewed']) ? (array) explode('|', sanitize_text_field(wp_unslash($_COOKIE['woocommerce_recently_viewed']))) : [];

            if (empty($viewed_products)) {
                return;
            }

            $filtered_products = [];
            foreach ($viewed_products as $product_id) {
                if ($this->product_belongs_to_location($product_id)) {
                    $filtered_products[] = $product_id;
                }
            }

            if (count($filtered_products) !== count($viewed_products)) {
                $filtered_cookie = implode('|', $filtered_products);
                wc_setcookie('woocommerce_recently_viewed', $filtered_cookie, time() + 60 * 60 * 24 * 30);
            }
        }







        private function should_apply_filtering($section)
        {
            $options = $this->get_display_options();
            $location = $this->get_current_location();
            if (!$location || $location === 'all-products') {
                return false;
            }

            if (isset($options['strict_filtering']) && $options['strict_filtering'] === 'disabled') {
                return false;
            }

            $filtered_sections = isset($options['filtered_sections']) ? $options['filtered_sections'] : [];
            return in_array($section, $filtered_sections);
        }

        private function get_filtered_location($section)
        {
            if (!$this->should_apply_filtering($section)) {
                return false;
            }
            return $this->get_current_location();
        }

        public function filter_products_by_location($query)
        {
            if (is_admin() || !$query->is_main_query()) {
                return;
            }

            $section = '';
            if (is_shop() || is_product_category() || is_product_tag() || is_post_type_archive('product')) {
                $section = 'shop';
            } elseif (is_search()) {
                $section = 'search';
            } else {
                return;
            }

            $location = $this->get_filtered_location($section);
            if (!$location) {
                return;
            }

            $tax_query = (array) $query->get('tax_query');
            global $mulopimfwc_options;
            $enable_all_locations = isset($mulopimfwc_options['enable_all_locations']) ? $mulopimfwc_options['enable_all_locations'] : 'off';

            if ($enable_all_locations === 'on') {
                $tax_query[] = [
                    'relation' => 'OR',
                    [
                        'taxonomy' => 'mulopimfwc_store_location',
                        'field' => 'slug',
                        'terms' => $location,
                    ],
                    [
                        'taxonomy' => 'mulopimfwc_store_location',
                        'operator' => 'NOT EXISTS',
                    ],
                ];
            } else {
                $tax_query[] = [
                    'taxonomy' => 'mulopimfwc_store_location',
                    'field' => 'slug',
                    'terms' => $location,
                ];
            }
            $query->set('tax_query', $tax_query);

            // Add custom ordering based on product priority display setting
            $product_priority_display = isset($options['product_priority_display']) ? $options['product_priority_display'] : 'location_first';

            if ($product_priority_display !== 'mixed' && $enable_all_locations === 'on' && mulopimfwc_premium_feature()) {
                add_filter('posts_join', [$this, 'custom_product_join'], 10, 2);
                add_filter('posts_orderby', [$this, 'custom_product_orderby'], 10, 2);
            }
        }

        /**
         * Add custom JOIN clause for location-based ordering
         *
         * @param string $join The JOIN clause
         * @param WP_Query $query The WordPress query object
         * @return string Modified JOIN clause
         */
        public function custom_product_join($join, $query)
        {
            global $wpdb;

            // Only apply to main product queries
            if (!$query->is_main_query() || !is_post_type_archive('product') && !is_shop() && !is_product_taxonomy()) {
                return $join;
            }

            $location = $this->get_current_location();
            if (!$location) {
                return $join;
            }

            $term = get_term_by('slug', $location, 'mulopimfwc_store_location');
            if (!$term || is_wp_error($term)) {
                return $join;
            }

            $term_taxonomy_id = $wpdb->get_var($wpdb->prepare(
                "SELECT term_taxonomy_id FROM {$wpdb->term_taxonomy} WHERE term_id = %d AND taxonomy = %s",
                $term->term_id,
                'mulopimfwc_store_location'
            ));

            if ($term_taxonomy_id) {
                $join .= " LEFT JOIN {$wpdb->term_relationships} AS location_tr 
                        ON ({$wpdb->posts}.ID = location_tr.object_id AND location_tr.term_taxonomy_id = " . intval($term_taxonomy_id) . ") ";
            }

            // Remove this filter after execution
            remove_filter('posts_join', [$this, 'custom_product_join'], 10);

            return $join;
        }

        /**
         * Add custom ORDER BY clause for location-based ordering
         *
         * @param string $orderby The ORDER BY clause
         * @param WP_Query $query The WordPress query object
         * @return string Modified ORDER BY clause
         */
        public function custom_product_orderby($orderby, $query)
        {
            global $wpdb;

            // Only apply to main product queries
            if (!$query->is_main_query() || !is_post_type_archive('product') && !is_shop() && !is_product_taxonomy()) {
                return $orderby;
            }

            $options = $this->get_display_options();
            $product_priority_display = isset($options['product_priority_display']) ? $options['product_priority_display'] : 'location_first';

            if ($product_priority_display === 'location_first') {
                $priority_value_for_location = 1;
                $priority_value_for_global = 2;
            } else { // global_first
                $priority_value_for_location = 2;
                $priority_value_for_global = 1;
            }

            $custom_orderby = "CASE WHEN location_tr.object_id IS NOT NULL THEN {$priority_value_for_location} ELSE {$priority_value_for_global} END, ";

            // Remove this filter after execution
            remove_filter('posts_orderby', [$this, 'custom_product_orderby'], 10);

            return $custom_orderby . $orderby;
        }



        public function filter_related_products_by_location($related_products, $product_id, $args)
        {
            $location = $this->get_filtered_location('related');

            if (!$location) {
                return $related_products;
            }

            return array_filter($related_products, [$this, 'product_belongs_to_location']);
        }

        public function filter_cross_sells_by_location($cross_sells)
        {
            $location = $this->get_filtered_location('cross_sells');

            if (!$location) {
                return $cross_sells;
            }

            return array_filter($cross_sells, [$this, 'product_belongs_to_location']);
        }

        public function filter_upsells_by_location($upsell_ids, $product_id)
        {
            $location = $this->get_filtered_location('upsells');

            if (!$location) {
                return $upsell_ids;
            }

            return array_filter($upsell_ids, [$this, 'product_belongs_to_location']);
        }

        public function filter_widget_products_by_location($query_args)
        {
            $location = $this->get_filtered_location('widgets');

            if (!$location) {
                return $query_args;
            }

            // if (!isset($query_args['tax_query'])) {
            //     $query_args['tax_query'] = [];
            // }

            $query_args['tax_query'][] = [
                'taxonomy' => 'mulopimfwc_store_location',
                'field' => 'slug',
                'terms' => $location,
            ];

            return $query_args;
        }

        function clear_cart()
        {
            // Check if WooCommerce is active
            if (class_exists('WooCommerce')) {
                WC()->cart->empty_cart(); // Clear the cart
                wp_send_json_success(); // Send a success response
            } else {
                wp_send_json_error(); // Send an error response
            }

            wp_die(); // Always call wp_die() at the end of AJAX functions
        }

        function check_cart_products()
        {
            // Check if WooCommerce is active
            if (!class_exists('WooCommerce')) {
                wp_send_json_error('WooCommerce is not active.');
            }

            // Check if the cart has products
            $cart_has_products = !WC()->cart->is_empty();

            // Return response
            wp_send_json_success(array('cartHasProducts' => $cart_has_products));
        }
        function custom_admin_styles()
        {
            wp_enqueue_style('mulopimfwc-custom-admin-style', plugin_dir_url(__FILE__) . 'assets/css/admin-style.css', array(), "1.0.3.20");
        }
    }

    function mulopimfwc_location_wise_products_init()
    {
        new mulopimfwc_Location_Wise_Products();
    }

    add_action('plugins_loaded', 'mulopimfwc_location_wise_products_init', 100);


    // Add this to the main plugin file after the class definition

    // AJAX handler for saving user location
    add_action('wp_ajax_mulopimfwc_save_user_location', 'mulopimfwc_save_user_location');
    add_action('wp_ajax_nopriv_mulopimfwc_save_user_location', 'mulopimfwc_save_user_location');

    function mulopimfwc_save_user_location()
    {
        // Check nonce
        check_ajax_referer('mulopimfwc_save_user_location', 'mulopimfwc_save_user_location_nonce');

        // Get form data
        $label = isset($_POST['label']) ? sanitize_text_field($_POST['label']) : '';
        $street = isset($_POST['street']) ? sanitize_text_field($_POST['street']) : '';
        $apartment = isset($_POST['apartment']) ? sanitize_text_field($_POST['apartment']) : '';
        $city = isset($_POST['city']) ? sanitize_text_field($_POST['city']) : '';
        $state = isset($_POST['state']) ? sanitize_text_field($_POST['state']) : '';
        $postal = isset($_POST['postal']) ? sanitize_text_field($_POST['postal']) : '';
        $country = isset($_POST['country']) ? sanitize_text_field($_POST['country']) : '';
        $note = isset($_POST['note']) ? sanitize_textarea_field($_POST['note']) : '';
        $lat = isset($_POST['lat']) ? floatval($_POST['lat']) : 0;
        $lng = isset($_POST['lng']) ? floatval($_POST['lng']) : 0;

        // Check if we're editing an existing location
        $location_id = isset($_POST['location_id']) && !empty($_POST['location_id']) ? sanitize_text_field($_POST['location_id']) : uniqid();

        // Prepare location data
        $location_data = array(
            'id' => $location_id,
            'label' => $label,
            'street' => $street,
            'apartment' => $apartment,
            'city' => $city,
            'state' => $state,
            'postal' => $postal,
            'country' => $country,
            'note' => $note,
            'lat' => $lat,
            'lng' => $lng,
            'address' => $street . ', ' . $city . ', ' . $state . ' ' . $postal . ', ' . $country
        );

        $is_logged_in = is_user_logged_in();

        if ($is_logged_in) {
            $user_id = get_current_user_id();
            $user_locations = get_user_meta($user_id, 'mulopimfwc_user_locations', true);
            if (!is_array($user_locations)) {
                $user_locations = array();
            }

            // If editing an existing location, find and update it
            $found = false;
            foreach ($user_locations as $key => $location) {
                if ($location['id'] === $location_id) {
                    $user_locations[$key] = $location_data;
                    $found = true;
                    break;
                }
            }

            // If not found, add new location
            if (!$found) {
                $user_locations[] = $location_data;
            }

            // Update user meta
            update_user_meta($user_id, 'mulopimfwc_user_locations', $user_locations);

            wp_send_json_success(array(
                'logged_in' => true,
                'location_id' => $location_id,
                'label' => $label,
                'address' => $location_data['address']
            ));
        } else {
            // For non-logged-in users, we can't save the location permanently.
            wc_setcookie('mulopimfwc_user_location', $location_data['address'], time() + 60 * 60 * 24 * 30);
            wp_send_json_success(array(
                'logged_in' => false,
                'location_id' => $location_id,
                'label' => $label,
                'address' => $location_data['address']
            ));
        }
    }



    // AJAX handler for deleting user location
    add_action('wp_ajax_mulopimfwc_delete_user_location', 'mulopimfwc_delete_user_location');

    function mulopimfwc_delete_user_location()
    {

        // Get location ID
        $location_id = isset($_POST['location_id']) ? sanitize_text_field($_POST['location_id']) : '';

        error_log("You are deleting: " . $location_id);

        if (empty($location_id)) {
            wp_send_json_error(array('message' => 'Invalid location ID'));
        }

        $user_id = get_current_user_id();
        $user_locations = get_user_meta($user_id, 'mulopimfwc_user_locations', true);

        if (!is_array($user_locations)) {
            wp_send_json_error(array('message' => 'No saved locations found'));
        }

        // Find and remove the location
        $found = false;
        foreach ($user_locations as $key => $location) {
            if ($location['id'] === $location_id) {
                unset($user_locations[$key]);
                $found = true;
                break;
            }
        }

        if (!$found) {
            wp_send_json_error(array('message' => 'Location not found'));
        }

        // Re-index array
        $user_locations = array_values($user_locations);

        // Update user meta
        update_user_meta($user_id, 'mulopimfwc_user_locations', $user_locations);

        wp_send_json_success(array('message' => 'Location deleted successfully'));
    }










    require_once plugin_dir_path(__FILE__) . 'includes/analytics.php';

    class mulopimfwc_analytics_main
    {
        private $analytics;

        public function __construct()
        {
            global $mulopimfwc_options;
            // Initialize analytics with the correct plugin file path
            $this->analytics = new mulopimfwc_anaylytics(
                '04',
                'https://plugincy.com/wp-json/product-analytics/v1',
                "1.0.3.20",
                'Multi Location Product & Inventory Management for WooCommerce',
                __FILE__ // Pass the main plugin file
            );

            add_action('admin_footer',  array($this->analytics, "add_deactivation_feedback_form"));

            // Plugin hooks
            add_action('init', array($this, 'init'));
            if (!isset($mulopimfwc_options["allow_data_share"]) || (isset($mulopimfwc_options["allow_data_share"])  && $mulopimfwc_options["allow_data_share"] === 'on')) {
                add_action('admin_init', array($this, 'admin_init'));
            }

            // Handle deactivation feedback AJAX
            add_action('wp_ajax_mulopimfwc_send_deactivation_feedback', array($this, 'handle_deactivation_feedback'));
        }

        public function init()
        {
            // Any initialization code
        }

        public function admin_init()
        {
            // Send analytics data on first activation or weekly
            $this->maybe_send_analytics();
        }

        private function maybe_send_analytics()
        {
            $last_sent = get_option('onepaquc_analytics_last_sent', 0);
            $week_ago = strtotime('-1 week');

            if ($last_sent < $week_ago) {
                $this->analytics->send_tracking_data();
                update_option('onepaquc_analytics_last_sent', time());
            }
        }

        public function handle_deactivation_feedback()
        {
            check_ajax_referer('deactivation_feedback', 'nonce');

            $reason = sanitize_text_field(wp_unslash($_POST['reason'] ?? ''));
            $this->analytics->send_deactivation_data($reason);

            wp_die();
        }
    }

    new mulopimfwc_analytics_main();
}
