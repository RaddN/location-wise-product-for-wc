/**
 * Location-Based Recommendations JavaScript
 * Place in: assets/js/recommendations.js
 */

(function($) {
    'use strict';

    const recommendationsConfig = window.mulopimfwcRecommendations || {};
    const recommendationsI18n = recommendationsConfig.i18n || {};
    const recommendationMessages = {
        loading: recommendationsI18n.loading || 'Loading recommendations...',
        noResults: recommendationsI18n.noResults || 'No recommendations available yet for this location.',
        error: recommendationsI18n.error || 'An error occurred while loading recommendations. Please try again.',
        selectLocation: recommendationsI18n.selectLocation || 'Please select a location to see recommendations.',
        added: recommendationsI18n.added || 'Added to cart!'
    };

    function normalizeText(text) {
        return (text || '').toString().trim().toLowerCase();
    }

    /**
     * Recommendations Manager
     */
    const RecommendationsManager = {
        
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
            this.refreshOnLocationChange();
        },

        /**
         * Bind event listeners
         */
        bindEvents: function() {
            // Refresh recommendations when location changes via various selectors
            $(document).on('change', '.mulopimfwc-location-selector, #mulopimfwc_store_location, .mulopimfwc-location-checkbox, .mulopimfwc-location-dropdown', 
                this.handleLocationChange.bind(this)
            );
            
            // Handle location change via buttons
            $(document).on('click', '.mulopimfwc-location-button', 
                (e) => {
                    const location = $(e.currentTarget).data('location');
                    if (location && location !== 'all-products') {
                        // Delay to allow cookie to be set
                        setTimeout(() => {
                            this.refreshRecommendations(location);
                        }, 300);
                    } else {
                        this.hideRecommendations();
                    }
                }
            );
            
            // Listen for custom location change events
            $(document).on('mulopimfwc:location-changed', (e, locationSlug) => {
                if (locationSlug && locationSlug !== 'all-products') {
                    setTimeout(() => {
                        this.refreshRecommendations(locationSlug);
                    }, 300);
                } else {
                    this.hideRecommendations();
                }
            });

            // Handle add to cart from recommendations
            $(document).on('click', '.mulopimfwc-recommendation-actions .add_to_cart_button', 
                this.handleAddToCart.bind(this)
            );

            // Track recommendation clicks
            $(document).on('click', '.mulopimfwc-recommendation-link', 
                this.trackRecommendationClick.bind(this)
            );
        },

        /**
         * Handle location change
         */
        handleLocationChange: function(e) {
            const locationSlug = $(e.target).val();
            
            if (locationSlug && locationSlug !== 'all-products') {
                // Delay to allow cookie to be set
                setTimeout(() => {
                    this.refreshRecommendations(locationSlug);
                }, 300);
            } else {
                this.hideRecommendations();
            }
        },

        /**
         * Refresh recommendations for a location
         */
        refreshRecommendations: function(locationSlug) {
            const $containers = $('.mulopimfwc-recommendations-container');
            
            if ($containers.length === 0) {
                return;
            }

            $containers.each(function() {
                const $container = $(this);
                const limit = $container.data('limit') || 8;

                // Show loading state
                RecommendationsManager.showLoading($container);

                // Fetch recommendations
                $.ajax({
                    url: mulopimfwcRecommendations.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'mulopimfwc_get_recommendations',
                        location: locationSlug,
                        limit: limit,
                        nonce: mulopimfwcRecommendations.nonce
                    },
                    success: function(response) {
                        if (response.success && response.data.count > 0) {
                            // Reload the page to show updated recommendations
                            // In a more advanced implementation, you could dynamically update the HTML
                            location.reload();
                        } else {
                            RecommendationsManager.showNoResults($container);
                        }
                    },
                    error: function() {
                        RecommendationsManager.showError($container);
                    }
                });
            });
        },

        /**
         * Show loading state
         */
        showLoading: function($container) {
            const $grid = $container.find('.mulopimfwc-recommendations-grid');
            $grid.html('<div class="mulopimfwc-recommendations-loading">' + recommendationMessages.loading + '</div>');
        },

        /**
         * Show no results message
         */
        showNoResults: function($container) {
            const $grid = $container.find('.mulopimfwc-recommendations-grid');
            $grid.html('<div class="mulopimfwc-recommendations-notice">' + recommendationMessages.noResults + '</div>');
        },

        /**
         * Show error message
         */
        showError: function($container) {
            const $grid = $container.find('.mulopimfwc-recommendations-grid');
            $grid.html('<div class="mulopimfwc-recommendations-notice" style="border-color: #e74c3c; background: #ffe8e8;">' + recommendationMessages.error + '</div>');
        },

        /**
         * Hide recommendations
         */
        hideRecommendations: function() {
            const $containers = $('.mulopimfwc-recommendations-container');
            $containers.each(function() {
                const $container = $(this);
                const $grid = $container.find('.mulopimfwc-recommendations-grid');
                $grid.html('<div class="mulopimfwc-recommendations-notice">' + recommendationMessages.selectLocation + '</div>');
            });
        },

        /**
         * Refresh on location change from cookie
         */
        refreshOnLocationChange: function() {
            const $containers = $('.mulopimfwc-recommendations-container');
            
            // If no containers exist, nothing to do
            if ($containers.length === 0) {
                return;
            }
            
            // Check if recommendations are already rendered with actual content (items, not just notices)
            let hasRenderedItems = false;
            $containers.each(function() {
                const $container = $(this);
                const $grid = $container.find('.mulopimfwc-recommendations-grid');
                const $items = $grid.find('.mulopimfwc-recommendation-item');
                
                // If there are recommendation items, content is already rendered server-side
                if ($items.length > 0) {
                    hasRenderedItems = true;
                    return false; // Break out of each loop
                }
            });
            
            // If recommendations are already rendered with items, don't interfere
            // Server-side rendering already handled it correctly
            if (hasRenderedItems) {
                // Just enhance the display, don't hide or modify
                this.enhanceRecommendations();
                return;
            }
            
            // Only check cookie and potentially hide if there are no rendered items
            // This means either:
            // 1. No location was set when page loaded (showing "select location" message)
            // 2. Location was set but no products available (showing "no recommendations" message)
            
            // Check if location cookie changed
            const storeCookieName =
                (window.mulopimfwc_locationWiseProducts && mulopimfwc_locationWiseProducts.cookieName)
                    ? mulopimfwc_locationWiseProducts.cookieName
                    : 'mulopimfwc_store_location';
            let currentLocation = this.getCookie(storeCookieName);
            
            // Decode URL-encoded cookie value
            if (currentLocation) {
                try {
                    currentLocation = decodeURIComponent(currentLocation);
                } catch (e) {
                    // If decoding fails, use original value
                }
            }
            
            if (currentLocation && currentLocation !== 'all-products') {
                // Location is set but no items rendered - might be "no recommendations" message
                // Don't hide it, server-side already handled it correctly
                // Just enhance if there's any content
                this.enhanceRecommendations();
            } else {
                // No location set - check if we need to show "select location" message
                // Only update if there's a grid that doesn't already have the message
                $containers.each(function() {
                    const $container = $(this);
                    const $grid = $container.find('.mulopimfwc-recommendations-grid');
                    const $notice = $grid.find('.mulopimfwc-recommendations-notice');
                    
                    // Only hide/replace if there's content that's not already the "select location" message
                    const noticeText = normalizeText($notice.text());
                    if ($notice.length === 0 || noticeText !== normalizeText(recommendationMessages.selectLocation)) {
                        // Check if there are any items (shouldn't be, but double-check)
                        if ($grid.find('.mulopimfwc-recommendation-item').length === 0) {
                            // No items and not already showing "select location" - show the message
                            $grid.html('<div class="mulopimfwc-recommendations-notice">' + recommendationMessages.selectLocation + '</div>');
                        }
                    }
                });
            }
        },

        /**
         * Enhance recommendations display
         */
        enhanceRecommendations: function() {
            // Add animations
            $('.mulopimfwc-recommendation-item').each(function(index) {
                $(this).css({
                    'opacity': '0',
                    'transform': 'translateY(0px)'
                }).delay(index * 100).animate({
                    'opacity': '1',
                    'transform': 'translateY(-20px)'
                }, 400);
            });

            // Lazy load images if needed
            this.lazyLoadImages();

            // Handle out of stock products
            this.handleOutOfStock();
        },

        /**
         * Lazy load images
         */
        lazyLoadImages: function() {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        const src = img.dataset.src;
                        
                        if (src) {
                            img.src = src;
                            img.removeAttribute('data-src');
                            observer.unobserve(img);
                        }
                    }
                });
            });

            $('.mulopimfwc-recommendation-image img[data-src]').each(function() {
                imageObserver.observe(this);
            });
        },

        /**
         * Handle out of stock products
         */
        handleOutOfStock: function() {
            $('.mulopimfwc-recommendation-item').each(function() {
                const $item = $(this);
                const $button = $item.find('.add_to_cart_button');
                
                if ($button.hasClass('product_type_variable')) {
                    // Variable product - check if in stock
                    // This would need additional AJAX call for accurate stock status
                }
            });
        },

        /**
         * Handle add to cart from recommendations
         */
        handleAddToCart: function(e) {
            const $button = $(e.currentTarget);
            const productId = $button.data('product_id');
            
            // Track the add to cart action
            this.trackAction('add_to_cart', productId);

            // Visual feedback
            $button.addClass('loading');
            
            // The default WooCommerce AJAX will handle the actual add to cart
            // We just track it here
        },

        /**
         * Track recommendation click
         */
        trackRecommendationClick: function(e) {
            const $link = $(e.currentTarget);
            const $item = $link.closest('.mulopimfwc-recommendation-item');
            const productId = $item.find('.add_to_cart_button').data('product_id');
            
            if (productId) {
                this.trackAction('click', productId);
            }
        },

        /**
         * Track action via AJAX
         */
        trackAction: function(actionType, productId) {
            $.ajax({
                url: mulopimfwcRecommendations.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'mulopimfwc_track_recommendation_action',
                    action_type: actionType,
                    product_id: productId,
                    nonce: mulopimfwcRecommendations.nonce
                },
                // Silent tracking - no need to handle response
                error: function() {
                    // Silently fail
                }
            });
        },

        /**
         * Get cookie value
         */
        getCookie: function(name) {
            const value = `; ${document.cookie}`;
            const parts = value.split(`; ${name}=`);
            if (parts.length === 2) {
                const raw = parts.pop().split(';').shift();
                if (raw) {
                    try {
                        return decodeURIComponent(raw);
                    } catch (e) {
                        return raw;
                    }
                }
                return raw;
            }
            return null;
        },

        /**
         * Format price
         */
        formatPrice: function(price) {
            // This would need to respect WooCommerce currency settings
            return '$' + parseFloat(price).toFixed(2);
        }
    };

    /**
     * Smooth scroll to recommendations
     */
    function scrollToRecommendations() {
        const $recommendations = $('.mulopimfwc-recommendations-container');
        
        if ($recommendations.length) {
            $('html, body').animate({
                scrollTop: $recommendations.offset().top - 100
            }, 600);
        }
    }

    /**
     * Handle WooCommerce added to cart event
     */
    $(document.body).on('added_to_cart', function(event, fragments, cart_hash, $button) {
        if ($button.closest('.mulopimfwc-recommendation-item').length) {
            // Show success message
            const $item = $button.closest('.mulopimfwc-recommendation-item');
            const $message = $('<div class="mulopimfwc-added-message"></div>').text(recommendationMessages.added);
            
            $item.append($message);
            
            setTimeout(function() {
                $message.fadeOut(function() {
                    $(this).remove();
                });
            }, 2000);
        }
    });

    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        RecommendationsManager.init();
    });

    /**
     * Export for external use
     */
    window.MulopimfwcRecommendations = RecommendationsManager;

})(jQuery);
