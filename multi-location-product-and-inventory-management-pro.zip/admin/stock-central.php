<?php

if (!defined('ABSPATH')) exit;

class mulopimfwc_Stock_Central
{
    private $product_table;
    private $view_mode = 'modern';

    public function __construct() {}

    public function register_screen_options()
    {
        $this->get_product_table($this->get_current_view_mode());

        add_screen_option('per_page', [
            'label' => __('Number of items per page:', 'multi-location-product-and-inventory-management'),
            'default' => 20,
            'option' => 'mulopimfwc_stock_central_per_page',
        ]);
    }

    private function get_current_view_mode()
    {
        $requested_mode = isset($_REQUEST['stock_central_view'])
            ? sanitize_text_field(wp_unslash($_REQUEST['stock_central_view']))
            : '';
        if (!in_array($requested_mode, ['modern', 'classic'], true)) {
            $requested_mode = '';
        }

        $user_id = get_current_user_id();
        if ($requested_mode === '' && $user_id) {
            $saved_mode = get_user_meta($user_id, 'mulopimfwc_stock_central_view_mode', true);
            if (in_array($saved_mode, ['modern', 'classic'], true)) {
                $requested_mode = $saved_mode;
            }
        }

        if ($requested_mode === '') {
            $requested_mode = 'modern';
        }

        if ($user_id && isset($_REQUEST['stock_central_view'])) {
            update_user_meta($user_id, 'mulopimfwc_stock_central_view_mode', $requested_mode);
        }

        $this->view_mode = $requested_mode;
        return $this->view_mode;
    }

    private function get_product_table($view_mode = null)
    {
        if ($view_mode === null) {
            $view_mode = $this->get_current_view_mode();
        }

        if (
            $this->product_table instanceof mulopimfwc_Product_Location_Table &&
            method_exists($this->product_table, 'get_view_mode') &&
            $this->product_table->get_view_mode() === $view_mode
        ) {
            return $this->product_table;
        }

        // Include required file for WP_List_Table
        if (!class_exists('WP_List_Table')) {
            require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
        }

        // Include our custom table class
        require_once plugin_dir_path(__FILE__) . '../includes/class-product-location-table.php';

        $this->product_table = new mulopimfwc_Product_Location_Table($view_mode);

        return $this->product_table;
    }

    public function location_stock_page_content()
    {
        $view_mode = $this->get_current_view_mode();
        $is_classic_mode = $view_mode === 'classic';
        $product_table = $this->get_product_table($view_mode);
        $can_manage_products = class_exists('MULOPIMFWC_Location_Managers')
            ? MULOPIMFWC_Location_Managers::user_has_capability('manage_products')
            : current_user_can('manage_woocommerce');

        $modern_url = add_query_arg([
            'stock_central_view' => 'modern',
            'paged' => false,
        ]);
        $classic_url = add_query_arg([
            'stock_central_view' => 'classic',
            'paged' => false,
        ]);

        // Prepare the items to display in the table
        $product_table->prepare_items();

?>
        <div class="wrap mlsctock-cenral-main view-mode-<?php echo esc_attr($view_mode); ?>">
            <h1 style="display: none !important;"><?php echo esc_html__('Location Wise Products Stock Management', 'multi-location-product-and-inventory-management'); ?></h1>
            <div class="mlsctock-cenral-header">
                <div class="mlsctock-cenral-header-copy">
                    <h1><?php echo esc_html__('Location Wise Products Stock Management', 'multi-location-product-and-inventory-management'); ?></h1>
                    <p><?php echo esc_html__('Manage stock levels and prices for each product by location.', 'multi-location-product-and-inventory-management'); ?></p>
                </div>
                <div class="mulopimfwc-view-switch-wrap">
                    <div class="mulopimfwc-view-switch <?php echo $is_classic_mode ? 'is-classic' : 'is-modern'; ?>" role="group" aria-label="<?php echo esc_attr__('Stock Central View Mode', 'multi-location-product-and-inventory-management'); ?>">
                        <a href="<?php echo esc_url($modern_url); ?>" class="mulopimfwc-view-switch-option <?php echo $is_classic_mode ? '' : 'is-active'; ?>">
                            <?php echo esc_html__('Modern', 'multi-location-product-and-inventory-management'); ?>
                        </a>
                        <a href="<?php echo esc_url($classic_url); ?>" class="mulopimfwc-view-switch-option <?php echo $is_classic_mode ? 'is-active' : ''; ?>">
                            <?php echo esc_html__('Classic', 'multi-location-product-and-inventory-management'); ?>
                        </a>
                    </div>
                </div>
            </div>

            <form method="get" id="stock-central-form">
                <input type="hidden" name="page" value="<?php echo isset($_REQUEST['page']) ? esc_attr(sanitize_text_field(wp_unslash($_REQUEST['page']))) : 'location-stock-management'; ?>" />
                <input type="hidden" name="stock_central_view" value="<?php echo esc_attr($view_mode); ?>" />
                <?php if ($is_classic_mode && $can_manage_products) : ?>
                    <div class="mulopimfwc-classic-toolbar">
                        <div class="mulopimfwc-classic-toolbar-left">
                            <strong class="mulopimfwc-classic-toolbar-title"><?php echo esc_html__('Classic Row Editor', 'multi-location-product-and-inventory-management'); ?></strong>
                            <span class="mulopimfwc-classic-toolbar-hint"><?php echo esc_html__('Edit product rows inline, then save or reset all changes.', 'multi-location-product-and-inventory-management'); ?></span>
                        </div>
                        <div class="mulopimfwc-classic-toolbar-right">
                            <button type="button" class="button button-primary" id="mulopimfwc-classic-save-all">
                                <?php echo esc_html__('Save All Product Changes', 'multi-location-product-and-inventory-management'); ?>
                            </button>
                            <button type="button" class="button button-secondary" id="mulopimfwc-classic-reset-all" disabled="disabled">
                                <?php echo esc_html__('Reset All Changes', 'multi-location-product-and-inventory-management'); ?>
                            </button>
                            <span id="mulopimfwc-classic-dirty-count" class="description">
                                <?php echo esc_html__('No unsaved product rows.', 'multi-location-product-and-inventory-management'); ?>
                            </span>
                        </div>
                    </div>
                <?php endif; ?>
                <?php $product_table->search_box(__('Search Products', 'multi-location-product-and-inventory-management'), 'search_products'); ?>
                <?php $product_table->display(); ?>
            </form>
        </div>

        <style>
            .mlsctock-cenral-main {
                border: 2px solid #d1d1d4;
                border-radius: 8px;
                background-color: #f9fafb;
                margin: 20px 20px 0px 0px;
            }

            .mlsctock-cenral-header {
                background-image: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                padding: 25px 25px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                display: flex;
                align-items: flex-start;
                justify-content: space-between;
                gap: 16px;
                box-sizing: border-box;
                width: 100%;
            }

            .mlsctock-cenral-header-copy {
                flex: 1 1 auto;
                min-width: 240px;
            }

            .mlsctock-cenral-header h1 {
                color: #ffffff;
                font-weight: 700;
                font-size: 30px;
                padding: 0;
                margin: 0;
            }

            .mlsctock-cenral-header p {
                color: #f3e8ff;
                font-size: 18px;
                margin: 6px 0px 0px;
            }

            .mulopimfwc-view-switch-wrap {
                flex: 0 0 auto;
                margin-left: auto;
                padding-top: 4px;
            }

            .mulopimfwc-view-switch {
                position: relative;
                display: inline-grid;
                grid-template-columns: 1fr 1fr;
                min-width: 200px;
                padding: 3px;
                border-radius: 999px;
                background: rgba(255, 255, 255, 0.16);
                border: 1px solid rgba(255, 255, 255, 0.32);
                backdrop-filter: blur(2px);
                transition: background 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease, transform 0.18s ease;
            }

            .mulopimfwc-view-switch:hover {
                background: rgba(255, 255, 255, 0.24);
                border-color: rgba(255, 255, 255, 0.55);
                box-shadow: 0 6px 18px rgba(15, 23, 42, 0.2);
                transform: translateY(-1px);
            }

            .mulopimfwc-view-switch::after {
                content: "";
                position: absolute;
                top: 3px;
                bottom: 3px;
                left: 3px;
                width: calc(50% - 3px);
                border-radius: 999px;
                background: #ffffff;
                box-shadow: 0 2px 6px rgba(15, 23, 42, 0.25);
                transition: transform 0.18s ease;
                pointer-events: none;
            }

            .mulopimfwc-view-switch.is-classic::after {
                transform: translateX(100%);
            }

            .mulopimfwc-view-switch-option {
                position: relative;
                z-index: 1;
                text-align: center;
                padding: 8px 14px;
                font-size: 13px;
                font-weight: 600;
                color: rgba(255, 255, 255, 0.85);
                text-decoration: none;
                border-radius: 999px;
                transition: color 0.18s ease, background 0.18s ease;
            }

            .mulopimfwc-view-switch-option:hover {
                color: #ffffff;
            }

            .mulopimfwc-view-switch-option:not(.is-active):hover {
                background: rgba(255, 255, 255, 0.14);
            }

            .mulopimfwc-view-switch-option:focus {
                outline: none;
                box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.55);
            }

            .mulopimfwc-view-switch-option.is-active {
                color: #111827;
            }

            .mulopimfwc-classic-toolbar {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 16px;
                margin-bottom: 16px;
                padding: 12px 14px;
                border: 1px solid #d6d9df;
                background: #f8f9fb;
                border-radius: 6px;
                position: sticky;
                top: 32px;
                z-index: 20;
                box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);
            }

            .mulopimfwc-classic-toolbar-left {
                display: flex;
                flex-direction: column;
                gap: 2px;
                min-width: 220px;
            }

            .mulopimfwc-classic-toolbar-title {
                font-size: 13px;
                font-weight: 700;
                color: #111827;
                line-height: 1.3;
            }

            .mulopimfwc-classic-toolbar-hint {
                font-size: 12px;
                color: #6b7280;
                line-height: 1.35;
            }

            .mulopimfwc-classic-toolbar-right {
                display: flex;
                align-items: center;
                gap: 10px;
                flex-wrap: wrap;
                justify-content: flex-end;
            }

            @media (max-width: 782px) {
                .mlsctock-cenral-header {
                    flex-direction: column;
                    align-items: flex-start;
                }

                .mulopimfwc-view-switch-wrap {
                    width: 100%;
                    margin-left: 0;
                    display: flex;
                    justify-content: flex-end;
                }

                .mulopimfwc-classic-toolbar {
                    top: 46px;
                    flex-direction: column;
                    align-items: flex-start;
                }

                .mulopimfwc-classic-toolbar-right {
                    width: 100%;
                    justify-content: flex-start;
                }
            }

            .mlsctock-cenral-main form {
                padding: 20px 25px;
                background-color: #ffffff;
            }

            .mlsctock-cenral-main form table {
                border-color: #e5e7eb !important;
            }

            .mlsctock-cenral-main form table thead {
                background-color: #e5e7eb;
            }

            .mlsctock-cenral-main form .widefat thead td,
            .mlsctock-cenral-main form .widefat thead th {
                border-bottom: 1px solid #e5e7eb !important;
            }

            .mlsctock-cenral-main form .alternate,
            .mlsctock-cenral-main form .striped>tbody>:nth-child(odd),
            .mlsctock-cenral-main form ul.striped>:nth-child(odd) {
                background-color: #f9fafb;
            }

            .mlsctock-cenral-main form .widefat td,
            .mlsctock-cenral-main form .widefat th {
                padding: 10px 10px;
            }

            .mlsctock-cenral-main form .widefat td,
            .mlsctock-cenral-main form th.check-column {
                padding: 20px 10px;
            }

            .mlsctock-cenral-main form th#image {
                width: 5%;
            }

            .mlsctock-cenral-main form .product-thumbnail {
                border-radius: 6px;
            }

            .mlsctock-cenral-main form .widefat thead th {
                font-size: 16px;
                font-weight: 500;
            }

            .mlsctock-cenral-main .mulopimfwc-product-id {
                color: #6b7280;
                font-weight: 400;
            }

            .mlsctock-cenral-main form .deactivate-location {
                background-color: #fef2f2;
                color: #dc2626;
                border-color: #fecaca;
            }

            .mlsctock-cenral-main form .activate-location {
                background-color: #f0fdf4;
                color: #15803d;
                border-color: #bbf7d0;
            }

            .mlsctock-cenral-main form .add-location,
            a.button.button-small.manage-product-location {
                background: #2563eb ! important;
                border-color: #2563eb !important;
                color: #ffffff;
                padding: 5px !important;
                font-weight: 500;
                font-size: 13px !important;
                width: 100%;
                text-align: center;
            }

            .mlsctock-cenral-main form .gross-profit-container,
            .mlsctock-cenral-main form .purchase-price-container {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }

            .mlsctock-cenral-main form .gross-profit-container .amount bdi {
                color: #15803d;
                font-weight: 500;
                font-size: 14px;
                background-color: #f0fdf4;
                padding: 2px;
                margin-right: 4px;
            }

            .location-actions {
                margin-bottom: 0px;
            }

            /* Accordion Styles */
            .variation-stock-item.accordion-item,
            .variation-price-item.accordion-item,
            .variation-gross-profit-item.accordion-item {
                margin-bottom: 10px;
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                overflow: hidden;
                background-color: #ffffff;
            }

            .variation-stock-item .accordion-header,
            .variation-price-item .accordion-header,
            .variation-gross-profit-item .accordion-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px 12px;
                background-color: #f9fafb;
                cursor: pointer;
                user-select: none;
                transition: background-color 0.2s ease;
                border-bottom: 1px solid #e5e7eb;
            }

            .variation-stock-item .accordion-header:hover,
            .variation-price-item .accordion-header:hover,
            .variation-gross-profit-item .accordion-header:hover {
                background-color: #f3f4f6;
            }

            .variation-stock-item.accordion-expanded .accordion-header,
            .variation-price-item.accordion-expanded .accordion-header,
            .variation-gross-profit-item.accordion-expanded .accordion-header {
                background-color: #e5e7eb;
            }

            .variation-stock-item .accordion-header strong,
            .variation-price-item .accordion-header strong,
            .variation-gross-profit-item .accordion-header strong {
                font-weight: 600;
                color: #374151;
                flex: 1;
            }

            .accordion-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 24px;
                height: 24px;
                font-size: 18px;
                font-weight: bold;
                color: #6b7280;
                border-radius: 4px;
                background-color: #ffffff;
                transition: transform 0.2s ease;
            }

            .variation-stock-item .accordion-content,
            .variation-price-item .accordion-content,
            .variation-gross-profit-item .accordion-content {
                max-height: 0;
                overflow: hidden;
                transition: max-height 0.3s ease, padding 0.3s ease;
                padding: 0 12px;
            }

            .variation-stock-item .accordion-content.accordion-open,
            .variation-price-item .accordion-content.accordion-open,
            .variation-gross-profit-item .accordion-content.accordion-open {
                max-height: 2000px;
                padding: 10px 12px;
            }

            .variation-stock-item .accordion-content .location-stock-item,
            .variation-price-item .accordion-content .location-price-item,
            .variation-gross-profit-item .accordion-content .location-gross-profit-item {
                margin-bottom: 8px;
            }

            .variation-stock-item .accordion-content .location-stock-item:last-child,
            .variation-price-item .accordion-content .location-price-item:last-child,
            .variation-gross-profit-item .accordion-content .location-gross-profit-item:last-child {
                margin-bottom: 0;
            }

            /* Filter styles */
            .mlsctock-cenral-main form .alignleft.actions.filters-section {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                align-items: center;
                margin-bottom: 15px;
            }

            .mlsctock-cenral-main form .alignleft.actions select {
                min-width: 150px;
                padding: 5px;
            }

            .mlsctock-cenral-main form .alignleft.actions #filter-submit {
                margin-left: 0;
            }

            /* Bulk actions section - positioned near bulk actions dropdown */
            .mlsctock-cenral-main form .alignleft.actions.bulk-actions-section {
                display: flex;
                align-items: center;
                gap: 5px;
                margin-left: 10px;
                margin-bottom: 15px;
                padding: 8px 12px;
                background-color: #f0f9ff;
                border: 1px solid #bae6fd;
                border-radius: 4px;
                margin-top: -45px;
            }

            .mlsctock-cenral-main form .alignleft.actions.bulk-actions-section label {
                font-weight: 500;
                white-space: nowrap;
            }

            .view-mode-classic thead th {
                font-size: 13px !important;
            }

            /* Bulk actions notice */
            .mlsctock-cenral-main .notice {
                margin: 15px 0;
            }

            .mlsctock-cenral-main.view-mode-classic {
                border-color: #cfd6dc;
                background-color: #f3f4f6;
            }

            .mlsctock-cenral-main.view-mode-classic .mlsctock-cenral-header {
                background: linear-gradient(135deg, #1f2937 0%, #374151 100%);
            }

            .mlsctock-cenral-main.view-mode-classic form {
                background: #ffffff;
            }

            .view-mode-classic .column-actions {
                width: 5%;
            }

            .view-mode-classic .column-title {
                width: 10%;
            }

            .view-mode-classic .column-classic_manage_stock,
            .view-mode-classic .column-classic_purchase {
                width: 12%;
            }

            .view-mode-classic .column-classic_default {
                width: 15%;
            }

            .view-mode-classic .column-classic_location_wise {
                width: 29%;
            }

            .mulopimfwc-classic-editor {
                display: flex;
                flex-direction: column;
                gap: 14px;
            }

            .mulopimfwc-classic-section {
                border: 1px solid #dde2e8;
                border-radius: 6px;
                padding: 10px;
                background: #fbfcfd;
                margin-top: 10px;
            }

            td .mulopimfwc-classic-section:first-child {
                margin-top: 0;
            }

            .mulopimfwc-classic-section h4 {
                margin: 0 0 10px;
                font-size: 13px;
                color: #1f2937;
            }

            .mulopimfwc-classic-section-head {
                display: flex;
                align-items: center;
                justify-content: space-between;
                gap: 12px;
                margin-bottom: 8px;
            }

            .mulopimfwc-classic-add-location-wrap {
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .mulopimfwc-classic-add-location-wrap select {
                min-width: 180px;
            }

            .mulopimfwc-classic-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
                gap: 8px 10px;
            }

            .mulopimfwc-classic-grid label {
                display: block;
                font-size: 11px;
                font-weight: 600;
                color: #4b5563;
                margin-bottom: 4px;
            }

            .mulopimfwc-classic-checkbox-wrap {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                font-size: 12px;
                color: #1f2937;
                font-weight: 600;
                margin-bottom: 0;
            }

            .mulopimfwc-classic-checkbox-wrap input[type="checkbox"] {
                margin: 0;
            }

            .mulopimfwc-classic-variation-manage-list {
                display: grid;
                gap: 8px;
            }

            .mulopimfwc-classic-variation-manage-item {
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                padding: 8px 10px;
                background: #ffffff;
            }

            .mulopimfwc-classic-variation-manage-title {
                font-weight: 600;
                color: #1f2937;
            }

            .mulopimfwc-classic-grid input:not([type="checkbox"]),
            .mulopimfwc-classic-grid select,
            .mulopimfwc-classic-location-table input,
            .mulopimfwc-classic-location-table select {
                width: 100%;
                min-height: 30px;
                font-size: 12px;
            }

            .mulopimfwc-classic-location-table th,
            .mulopimfwc-classic-location-table td {
                padding: 6px !important;
                vertical-align: middle;
                font-size: 12px;
            }

            .mulopimfwc-classic-location-label {
                font-weight: 600;
                color: #111827;
            }

            .mulopimfwc-classic-no-locations-row td {
                text-align: center;
                color: #6b7280;
                font-style: italic;
            }

            .mulopimfwc-classic-variation {
                border: 1px solid #e2e8f0;
                border-radius: 6px;
                background: #fff;
                margin-bottom: 10px;
            }

            .mulopimfwc-classic-variation summary {
                cursor: pointer;
                padding: 9px 10px;
                font-weight: 600;
                color: #1f2937;
                border-bottom: 1px solid #edf0f3;
            }

            .mulopimfwc-classic-variation[open] summary {
                background: #f8fafc;
            }

            .mulopimfwc-classic-variation .mulopimfwc-classic-grid {
                margin: 10px;
            }

            .mulopimfwc-classic-actions {
                display: inline-flex;
                align-items: center;
                gap: 8px;
            }

            .mulopimfwc-classic-reset-row,
            .mulopimfwc-classic-save-row {
                min-width: 34px;
                height: 32px;
                line-height: 1;
                padding: 0;
                font-size: 18px;
            }

            .mulopimfwc-classic-product-row.is-dirty .mulopimfwc-classic-save-row {
                box-shadow: 0 0 0 1px #2563eb;
            }

            .mulopimfwc-classic-row-status {
                font-size: 11px;
                color: #6b7280;
                min-width: 60px;
            }

            .mulopimfwc-classic-row-status.is-success {
                color: #166534;
            }

            .mulopimfwc-classic-row-status.is-error {
                color: #b91c1c;
            }
        </style>

        <script>
            (function($) {
                $(document).ready(function() {
                    // Initialize accordions - first item expanded
                    $('.location-stock-container, .location-price-container, .gross-profit-container').each(function() {
                        var $container = $(this);
                        var $accordionItems = $container.find('.accordion-item');

                        // First item should be expanded
                        $accordionItems.first().addClass('accordion-expanded').find('.accordion-content').addClass('accordion-open');
                        $accordionItems.first().find('.accordion-icon').text('-');
                    });

                    // Handle accordion toggle
                    $(document).on('click', '.accordion-header', function(e) {
                        e.preventDefault();
                        var $header = $(this);
                        var $item = $header.closest('.accordion-item');
                        var $content = $header.siblings('.accordion-content');
                        var $icon = $header.find('.accordion-icon');
                        var targetId = $header.data('accordion-target');

                        // Toggle expanded class
                        $item.toggleClass('accordion-expanded');
                        $content.toggleClass('accordion-open');

                        // Update icon
                        if ($item.hasClass('accordion-expanded')) {
                            $icon.text('-');
                        } else {
                            $icon.text('+');
                        }
                    });

                    // Handle form submission - update URL on submit
                    var $form = $('#stock-central-form');
                    var isClassicMode = <?php echo $is_classic_mode ? 'true' : 'false'; ?>;
                    var canManageProducts = <?php echo $can_manage_products ? 'true' : 'false'; ?>;
                    var rowSnapshots = {};
                    var ajaxNonce = (window.mulopimfwc_locationWiseProducts && mulopimfwc_locationWiseProducts.nonce) ? mulopimfwc_locationWiseProducts.nonce : '';
                    var editableClassicColumns = ['classic_manage_stock', 'classic_default', 'classic_location_wise', 'classic_purchase'];
                    var rowFieldSelector = editableClassicColumns.map(function(columnName) {
                        return '.column-' + columnName + ' [data-field]';
                    }).join(', ');

                    // Update URL when form is submitted
                    function updateURL() {
                        var formData = $form.serialize();
                        var url = window.location.pathname + '?' + formData;
                        window.history.pushState({
                            path: url
                        }, '', url);
                    }

                    // Handle form submission (Filter button or search)
                    $form.on('submit', function(e) {
                        updateURL();
                        // Form will submit normally
                    });

                    // Handle bulk action selection - validate but don't submit
                    $('select[name="action"], select[name="action2"]').on('change', function() {
                        var action = $(this).val();
                        // Just show/hide location selector, don't submit
                        toggleBulkLocationSelector();
                    });

                    // Handle bulk action Apply button click
                    $('input#doaction, input#doaction2').on('click', function(e) {
                        var $button = $(this);
                        var action = $('select[name="action"]').val();
                        var action2 = $('select[name="action2"]').val();
                        var currentAction = (action && action !== '-1') ? action : ((action2 && action2 !== '-1') ? action2 : '');

                        if (currentAction === 'bulk_assign_location' || currentAction === 'bulk_remove_location') {
                            if (!$('#bulk-location-id').val()) {
                                e.preventDefault();
                                alert('<?php echo esc_js(__('Please select a location first', 'multi-location-product-and-inventory-management')); ?>');
                                return false;
                            }
                        }
                        // If validation passes, form will submit normally
                    });

                    // Show/hide bulk location selector based on selected bulk action
                    function toggleBulkLocationSelector() {
                        var action = $('select[name="action"]').val();
                        var action2 = $('select[name="action2"]').val();
                        var currentAction = (action && action !== '-1') ? action : ((action2 && action2 !== '-1') ? action2 : '');

                        if (currentAction === 'bulk_assign_location' || currentAction === 'bulk_remove_location') {
                            $('.bulk-actions-section').fadeIn(200);
                        } else {
                            $('.bulk-actions-section').fadeOut(200);
                        }
                    }

                    // Move bulk actions section to be right after bulk actions dropdown
                    function positionBulkActionsSection() {
                        var $bulkActions = $('.tablenav.top .bulkactions, .tablenav.top .alignleft.actions.bulkactions');
                        var $bulkSection = $('.bulk-actions-section');

                        if ($bulkActions.length && $bulkSection.length) {
                            // Find the bulk actions container
                            var $bulkContainer = $bulkActions.closest('.alignleft, .bulkactions').parent();
                            if ($bulkContainer.length) {
                                $bulkSection.detach().insertAfter($bulkContainer);
                            } else {
                                $bulkSection.detach().insertAfter($bulkActions);
                            }
                        }
                    }

                    // Position on load and after any DOM changes
                    positionBulkActionsSection();

                    // Also position after table is ready
                    setTimeout(positionBulkActionsSection, 100);

                    // Initial state - hide by default
                    $('.bulk-actions-section').hide();
                    toggleBulkLocationSelector();

                    // Restore filters from URL on page load
                    var urlParams = new URLSearchParams(window.location.search);
                    if (urlParams.has('s') || urlParams.has('filter-by-location') || urlParams.has('filter-by-category') ||
                        urlParams.has('filter-by-type') || urlParams.has('filter-by-stock-status') || urlParams.has('filter-by-brand')) {
                        // Filters are already in URL, form will auto-populate
                    }

                    if (!isClassicMode || !canManageProducts) {
                        return;
                    }

                    function escapeHtml(text) {
                        return $('<div>').text(text || '').html();
                    }

                    function parseIds(raw) {
                        if (!raw) {
                            return [];
                        }

                        var ids = raw.toString().split(',').map(function(value) {
                            return parseInt($.trim(value), 10);
                        }).filter(function(value) {
                            return !isNaN(value) && value > 0;
                        });

                        ids.sort(function(a, b) {
                            return a - b;
                        });
                        return ids;
                    }

                    function arrayEquals(first, second) {
                        if (first.length !== second.length) {
                            return false;
                        }
                        for (var i = 0; i < first.length; i++) {
                            if (String(first[i]) !== String(second[i])) {
                                return false;
                            }
                        }
                        return true;
                    }

                    function showNotice(message, type) {
                        var noticeClass = 'notice notice-' + type + ' is-dismissible';
                        var $notice = $('<div class=\"' + noticeClass + ' mulopimfwc-classic-notice\"><p>' + message + '</p></div>');
                        $('.mulopimfwc-classic-notice').remove();
                        $('.mlsctock-cenral-main').prepend($notice);
                    }

                    function setRowStatus($row, text, type) {
                        var $status = $row.find('.mulopimfwc-classic-row-status');
                        $status.removeClass('is-success is-error');
                        if (type === 'success') {
                            $status.addClass('is-success');
                        } else if (type === 'error') {
                            $status.addClass('is-error');
                        }
                        $status.text(text || '');
                    }

                    function updateDirtyCount() {
                        var count = $('.mulopimfwc-classic-product-row.is-dirty').length;
                        var $count = $('#mulopimfwc-classic-dirty-count');
                        var $resetAll = $('#mulopimfwc-classic-reset-all');
                        if ($resetAll.length) {
                            $resetAll.prop('disabled', count === 0);
                        }
                        if (!$count.length) {
                            return;
                        }
                        if (count === 0) {
                            $count.text('<?php echo esc_js(__('No unsaved product rows.', 'multi-location-product-and-inventory-management')); ?>');
                        } else if (count === 1) {
                            $count.text('<?php echo esc_js(__('1 product row has unsaved changes.', 'multi-location-product-and-inventory-management')); ?>');
                        } else {
                            $count.text(count + ' <?php echo esc_js(__('product rows have unsaved changes.', 'multi-location-product-and-inventory-management')); ?>');
                        }
                    }

                    function setRowDirty($row, isDirty) {
                        $row.toggleClass('is-dirty', !!isDirty);
                        $row.find('.mulopimfwc-classic-save-row').prop('disabled', !isDirty);
                        $row.find('.mulopimfwc-classic-reset-row').prop('disabled', !isDirty);
                        updateDirtyCount();
                    }

                    function getFieldValue($field) {
                        if ($field.is(':checkbox')) {
                            return $field.is(':checked') ? 'yes' : 'no';
                        }

                        return ($field.val() || '').toString();
                    }

                    function storeRowSnapshot($row) {
                        var productId = String($row.data('product-id'));
                        var columnHtml = {};
                        editableClassicColumns.forEach(function(columnName) {
                            columnHtml[columnName] = $row.find('.column-' + columnName).html();
                        });

                        rowSnapshots[productId] = {
                            columnHtml: columnHtml,
                            originalLocationIds: $row.attr('data-original-location-ids') || ''
                        };
                    }

                    function resetRowFromSnapshot($row) {
                        var productId = String($row.data('product-id'));
                        var snapshot = rowSnapshots[productId];
                        if (!snapshot) {
                            return false;
                        }

                        if (snapshot.columnHtml) {
                            editableClassicColumns.forEach(function(columnName) {
                                if (snapshot.columnHtml.hasOwnProperty(columnName)) {
                                    $row.find('.column-' + columnName).html(snapshot.columnHtml[columnName]);
                                }
                            });
                        }

                        $row.attr('data-original-location-ids', snapshot.originalLocationIds);
                        setRowStatus($row, '');
                        setRowDirty($row, false);
                        return true;
                    }

                    function getCurrentLocationIds($row) {
                        var ids = [];
                        $row.find('.mulopimfwc-classic-product-location-table tbody tr.mulopimfwc-classic-product-location-row').each(function() {
                            var locationId = parseInt($(this).data('location-id'), 10);
                            if (!isNaN(locationId) && locationId > 0) {
                                ids.push(locationId);
                            }
                        });
                        ids.sort(function(a, b) {
                            return a - b;
                        });
                        return ids;
                    }

                    function isRowDirty($row) {
                        var dirty = false;
                        $row.find(rowFieldSelector).each(function() {
                            var $field = $(this);
                            var initial = ($field.attr('data-initial-value') || '').toString();
                            var current = getFieldValue($field);
                            if (initial !== current) {
                                dirty = true;
                                return false;
                            }
                        });
                        if (dirty) {
                            return true;
                        }

                        var originalIds = parseIds($row.attr('data-original-location-ids'));
                        var currentIds = getCurrentLocationIds($row);
                        return !arrayEquals(originalIds, currentIds);
                    }

                    function refreshRowAsSaved($row) {
                        var currentIds = getCurrentLocationIds($row);
                        $row.attr('data-original-location-ids', currentIds.join(','));
                        $row.find(rowFieldSelector).each(function() {
                            var $field = $(this);
                            $field.attr('data-initial-value', getFieldValue($field));
                        });
                        storeRowSnapshot($row);
                        setRowDirty($row, false);
                    }

                    function ensureNoLocationRow($table, colspan) {
                        var $tbody = $table.find('tbody');
                        var hasRows = $tbody.find('tr.mulopimfwc-classic-product-location-row, tr.mulopimfwc-classic-variation-location-row').length > 0;
                        if (hasRows) {
                            $tbody.find('.mulopimfwc-classic-no-locations-row').remove();
                        } else if (!$tbody.find('.mulopimfwc-classic-no-locations-row').length) {
                            $tbody.append('<tr class=\"mulopimfwc-classic-no-locations-row\"><td colspan=\"' + colspan + '\"><?php echo esc_js(__('No locations assigned yet.', 'multi-location-product-and-inventory-management')); ?></td></tr>');
                        }
                    }

                    function syncAllLocationsOption($select) {
                        if (!$select || !$select.length) {
                            return;
                        }

                        var hasRealOptions = $select.find('option').filter(function() {
                            var value = ($(this).val() || '').toString();
                            return value !== '' && value !== '__all__';
                        }).length > 0;
                        var hasAllOption = $select.find('option[value=\"__all__\"]').length > 0;

                        if (hasRealOptions && !hasAllOption) {
                            var $allOption = $('<option value=\"__all__\"><?php echo esc_js(__('All locations', 'multi-location-product-and-inventory-management')); ?></option>');
                            var $placeholder = $select.find('option[value=\"\"]').first();
                            if ($placeholder.length) {
                                $allOption.insertAfter($placeholder);
                            } else {
                                $select.prepend($allOption);
                            }
                        } else if (!hasRealOptions && hasAllOption) {
                            $select.find('option[value=\"__all__\"]').remove();
                        }
                    }

                    function buildProductLocationRow(locationId, locationName, supportsManageStock, rowMode) {
                        var disabled = supportsManageStock ? '' : ' disabled=\"disabled\"';
                        if (rowMode === 'location_only') {
                            return '' +
                                '<tr class=\"mulopimfwc-classic-product-location-row\" data-location-id=\"' + locationId + '\" data-location-name=\"' + escapeHtml(locationName) + '\">' +
                                '<td class=\"mulopimfwc-classic-location-label\">' + escapeHtml(locationName) + '</td>' +
                                '<td><button type=\"button\" class=\"button-link-delete mulopimfwc-classic-remove-location\" title=\"<?php echo esc_js(__('Remove location', 'multi-location-product-and-inventory-management')); ?>\">&#10005;</button></td>' +
                                '</tr>';
                        } else if (rowMode === 'price_only') {
                            return '' +
                                '<tr class=\"mulopimfwc-classic-product-location-row\" data-location-id=\"' + locationId + '\" data-location-name=\"' + escapeHtml(locationName) + '\">' +
                                '<td class=\"mulopimfwc-classic-location-label\">' + escapeHtml(locationName) + '</td>' +
                                '<td><input type=\"number\" class=\"mulopimfwc-classic-field mulopimfwc-classic-number\" data-field=\"regular_price\" data-initial-value=\"\" value=\"\" min=\"0\" step=\"0.01\"></td>' +
                                '<td><input type=\"number\" class=\"mulopimfwc-classic-field mulopimfwc-classic-number\" data-field=\"sale_price\" data-initial-value=\"\" value=\"\" min=\"0\" step=\"0.01\"></td>' +
                                '<td><button type=\"button\" class=\"button-link-delete mulopimfwc-classic-remove-location\" title=\"<?php echo esc_js(__('Remove location', 'multi-location-product-and-inventory-management')); ?>\">&#10005;</button></td>' +
                                '</tr>';
                        }

                        return '' +
                            '<tr class=\"mulopimfwc-classic-product-location-row\" data-location-id=\"' + locationId + '\" data-location-name=\"' + escapeHtml(locationName) + '\">' +
                            '<td class=\"mulopimfwc-classic-location-label\">' + escapeHtml(locationName) + '</td>' +
                            '<td><input type=\"number\" class=\"mulopimfwc-classic-field mulopimfwc-classic-number\" data-field=\"stock\" data-initial-value=\"\" value=\"\" min=\"0\" step=\"1\"' + disabled + '></td>' +
                            '<td><input type=\"number\" class=\"mulopimfwc-classic-field mulopimfwc-classic-number\" data-field=\"regular_price\" data-initial-value=\"\" value=\"\" min=\"0\" step=\"0.01\"></td>' +
                            '<td><input type=\"number\" class=\"mulopimfwc-classic-field mulopimfwc-classic-number\" data-field=\"sale_price\" data-initial-value=\"\" value=\"\" min=\"0\" step=\"0.01\"></td>' +
                            '<td><select class=\"mulopimfwc-classic-field mulopimfwc-classic-select\" data-field=\"backorders\" data-initial-value=\"off\"' + disabled + '>' +
                            '<option value=\"off\"><?php echo esc_js(__('Do not allow', 'multi-location-product-and-inventory-management')); ?></option>' +
                            '<option value=\"notify\"><?php echo esc_js(__('Allow, but notify', 'multi-location-product-and-inventory-management')); ?></option>' +
                            '<option value=\"on\"><?php echo esc_js(__('Allow', 'multi-location-product-and-inventory-management')); ?></option>' +
                            '</select></td>' +
                            '<td><button type=\"button\" class=\"button-link-delete mulopimfwc-classic-remove-location\" title=\"<?php echo esc_js(__('Remove location', 'multi-location-product-and-inventory-management')); ?>\">&#10005;</button></td>' +
                            '</tr>';
                    }

                    function buildVariationLocationRow(locationId, locationName) {
                        return '' +
                            '<tr class=\"mulopimfwc-classic-variation-location-row\" data-location-id=\"' + locationId + '\" data-location-name=\"' + escapeHtml(locationName) + '\">' +
                            '<td class=\"mulopimfwc-classic-location-label\">' + escapeHtml(locationName) + '</td>' +
                            '<td><input type=\"number\" class=\"mulopimfwc-classic-field mulopimfwc-classic-number\" data-field=\"stock\" data-initial-value=\"\" value=\"\" min=\"0\" step=\"1\"></td>' +
                            '<td><input type=\"number\" class=\"mulopimfwc-classic-field mulopimfwc-classic-number\" data-field=\"regular_price\" data-initial-value=\"\" value=\"\" min=\"0\" step=\"0.01\"></td>' +
                            '<td><input type=\"number\" class=\"mulopimfwc-classic-field mulopimfwc-classic-number\" data-field=\"sale_price\" data-initial-value=\"\" value=\"\" min=\"0\" step=\"0.01\"></td>' +
                            '<td><select class=\"mulopimfwc-classic-field mulopimfwc-classic-select\" data-field=\"backorders\" data-initial-value=\"off\">' +
                            '<option value=\"off\"><?php echo esc_js(__('Do not allow', 'multi-location-product-and-inventory-management')); ?></option>' +
                            '<option value=\"notify\"><?php echo esc_js(__('Allow, but notify', 'multi-location-product-and-inventory-management')); ?></option>' +
                            '<option value=\"on\"><?php echo esc_js(__('Allow', 'multi-location-product-and-inventory-management')); ?></option>' +
                            '</select></td>' +
                            '</tr>';
                    }

                    function collectRowPayload($row) {
                        var payload = {
                            action: 'save_product_quick_edit_data',
                            product_id: parseInt($row.data('product-id'), 10),
                            security: ajaxNonce,
                            default: {},
                            locations: [],
                            location_ids: [],
                            removed_location_ids: [],
                            variations: []
                        };

                        $row.find('.mulopimfwc-classic-default-field').each(function() {
                            var field = $(this).data('field');
                            if (field) {
                                payload.default[field] = getFieldValue($(this));
                            }
                        });

                        $row.find('.mulopimfwc-classic-product-location-table tbody tr.mulopimfwc-classic-product-location-row').each(function() {
                            var $locationRow = $(this);
                            var locationId = parseInt($locationRow.data('location-id'), 10);
                            if (isNaN(locationId) || locationId <= 0) {
                                return;
                            }
                            var locationPayload = {
                                id: locationId
                            };
                            $locationRow.find('[data-field]').each(function() {
                                var field = $(this).data('field');
                                if (field) {
                                    locationPayload[field] = getFieldValue($(this));
                                }
                            });
                            payload.locations.push(locationPayload);
                            payload.location_ids.push(locationId);
                        });

                        var originalIds = parseIds($row.attr('data-original-location-ids'));
                        payload.removed_location_ids = originalIds.filter(function(locationId) {
                            return payload.location_ids.indexOf(locationId) === -1;
                        });

                        var variationIds = [];
                        $row.find('[data-variation-id]').each(function() {
                            var variationId = parseInt($(this).data('variation-id'), 10);
                            if (!isNaN(variationId) && variationId > 0 && variationIds.indexOf(variationId) === -1) {
                                variationIds.push(variationId);
                            }
                        });

                        variationIds.sort(function(a, b) {
                            return a - b;
                        });
                        variationIds.forEach(function(variationId) {
                            var variationPayload = {
                                id: variationId,
                                default: {},
                                locations: []
                            };

                            $row.find('[data-variation-id=\"' + variationId + '\"] .mulopimfwc-classic-variation-default-field').each(function() {
                                var field = $(this).data('field');
                                if (field) {
                                    variationPayload.default[field] = getFieldValue($(this));
                                }
                            });

                            var $variationTable = $row.find('.mulopimfwc-classic-variation-location-table[data-variation-id=\"' + variationId + '\"]').first();
                            $variationTable.find('tbody tr.mulopimfwc-classic-variation-location-row').each(function() {
                                var $variationLocationRow = $(this);
                                var locationId = parseInt($variationLocationRow.data('location-id'), 10);
                                if (isNaN(locationId) || locationId <= 0) {
                                    return;
                                }
                                var variationLocationPayload = {
                                    id: locationId
                                };
                                $variationLocationRow.find('[data-field]').each(function() {
                                    var field = $(this).data('field');
                                    if (field) {
                                        variationLocationPayload[field] = getFieldValue($(this));
                                    }
                                });
                                variationPayload.locations.push(variationLocationPayload);
                            });

                            payload.variations.push(variationPayload);
                        });

                        return payload;
                    }

                    function saveRow($row) {
                        var deferred = $.Deferred();
                        var payload = collectRowPayload($row);
                        var $saveButton = $row.find('.mulopimfwc-classic-save-row');
                        var $resetButton = $row.find('.mulopimfwc-classic-reset-row');

                        setRowStatus($row, '<?php echo esc_js(__('Saving...', 'multi-location-product-and-inventory-management')); ?>');
                        $saveButton.prop('disabled', true).text('...');
                        $resetButton.prop('disabled', true);

                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: payload
                        }).done(function(response) {
                            if (response && response.success) {
                                refreshRowAsSaved($row);
                                setRowStatus($row, '<?php echo esc_js(__('Saved', 'multi-location-product-and-inventory-management')); ?>', 'success');
                                deferred.resolve(response);
                            } else {
                                var message = response && response.data && response.data.message ? response.data.message : '<?php echo esc_js(__('Unable to save this product row.', 'multi-location-product-and-inventory-management')); ?>';
                                setRowStatus($row, message, 'error');
                                setRowDirty($row, true);
                                deferred.reject(message);
                            }
                        }).fail(function() {
                            setRowStatus($row, '<?php echo esc_js(__('AJAX error while saving.', 'multi-location-product-and-inventory-management')); ?>', 'error');
                            setRowDirty($row, true);
                            deferred.reject();
                        }).always(function() {
                            $saveButton.html('&#10003;');
                            $resetButton.prop('disabled', !$row.hasClass('is-dirty'));
                        });

                        return deferred.promise();
                    }

                    $('.mulopimfwc-classic-product-row').each(function() {
                        var $row = $(this);
                        storeRowSnapshot($row);
                        setRowDirty($row, false);
                    });
                    updateDirtyCount();

                    $(document).on('input change', '.mulopimfwc-classic-product-row .column-classic_manage_stock [data-field], .mulopimfwc-classic-product-row .column-classic_default [data-field], .mulopimfwc-classic-product-row .column-classic_location_wise [data-field], .mulopimfwc-classic-product-row .column-classic_purchase [data-field]', function() {
                        var $row = $(this).closest('.mulopimfwc-classic-product-row');
                        setRowStatus($row, '');
                        setRowDirty($row, isRowDirty($row));
                    });

                    $(document).on('click', '.mulopimfwc-classic-add-location-btn', function() {
                        var $row = $(this).closest('.mulopimfwc-classic-product-row');
                        var $select = $row.find('.mulopimfwc-classic-add-location-select').first();
                        var selectedValue = ($select.val() || '').toString();
                        if (!selectedValue) {
                            return;
                        }

                        var locationsToAdd = [];
                        if (selectedValue === '__all__') {
                            $select.find('option').each(function() {
                                var value = ($(this).val() || '').toString();
                                if (value === '' || value === '__all__') {
                                    return;
                                }
                                var locationId = parseInt(value, 10);
                                if (isNaN(locationId) || locationId <= 0) {
                                    return;
                                }
                                locationsToAdd.push({
                                    id: locationId,
                                    name: $(this).text()
                                });
                            });
                        } else {
                            var locationId = parseInt(selectedValue, 10);
                            if (isNaN(locationId) || locationId <= 0) {
                                return;
                            }
                            locationsToAdd.push({
                                id: locationId,
                                name: $select.find('option:selected').text()
                            });
                        }

                        if (!locationsToAdd.length) {
                            syncAllLocationsOption($select);
                            return;
                        }

                        var productType = (($row.attr('data-product-type') || '') + '').toLowerCase();
                        var supportsManageStock = ['grouped', 'external', 'affiliate'].indexOf(productType) === -1;
                        var rowMode = 'full';
                        if (productType === 'variable' || productType === 'grouped') {
                            rowMode = 'location_only';
                        } else if (productType === 'external') {
                            rowMode = 'price_only';
                        }

                        $row.find('.mulopimfwc-classic-product-location-table .mulopimfwc-classic-no-locations-row').remove();
                        var $productTbody = $row.find('.mulopimfwc-classic-product-location-table tbody');
                        var $variationTables = $row.find('.mulopimfwc-classic-variation-location-table');
                        $variationTables.each(function() {
                            var $variationTable = $(this);
                            $variationTable.find('.mulopimfwc-classic-no-locations-row').remove();
                        });

                        var addedCount = 0;
                        locationsToAdd.forEach(function(locationData) {
                            if ($row.find('.mulopimfwc-classic-product-location-row[data-location-id=\"' + locationData.id + '\"]').length) {
                                return;
                            }

                            $productTbody.append(buildProductLocationRow(locationData.id, locationData.name, supportsManageStock, rowMode));

                            $variationTables.each(function() {
                                var $variationTable = $(this);
                                if ($variationTable.find('.mulopimfwc-classic-variation-location-row[data-location-id=\"' + locationData.id + '\"]').length) {
                                    return;
                                }
                                $variationTable.find('tbody').append(buildVariationLocationRow(locationData.id, locationData.name));
                            });

                            $select.find('option[value=\"' + locationData.id + '\"]').remove();
                            addedCount++;
                        });

                        $select.val('');
                        syncAllLocationsOption($select);
                        if (addedCount > 0) {
                            setRowDirty($row, true);
                        }
                    });

                    $(document).on('click', '.mulopimfwc-classic-remove-location', function() {
                        var $locationRow = $(this).closest('.mulopimfwc-classic-product-location-row');
                        var $row = $(this).closest('.mulopimfwc-classic-product-row');
                        var locationId = parseInt($locationRow.data('location-id'), 10);
                        var locationName = ($locationRow.data('location-name') || '').toString();

                        if (isNaN(locationId) || locationId <= 0) {
                            return;
                        }

                        $locationRow.remove();
                        $row.find('.mulopimfwc-classic-variation-location-row[data-location-id=\"' + locationId + '\"]').remove();

                        var productTableColspan = $row.find('.mulopimfwc-classic-product-location-table thead th').length || 6;
                        ensureNoLocationRow($row.find('.mulopimfwc-classic-product-location-table'), productTableColspan);
                        $row.find('.mulopimfwc-classic-variation-location-table').each(function() {
                            ensureNoLocationRow($(this), 5);
                        });

                        var $select = $row.find('.mulopimfwc-classic-add-location-select').first();
                        if ($select.find('option[value=\"' + locationId + '\"]').length === 0) {
                            $select.append('<option value=\"' + locationId + '\">' + escapeHtml(locationName) + '</option>');
                        }
                        syncAllLocationsOption($select);
                        setRowDirty($row, true);
                    });

                    $(document).on('click', '.mulopimfwc-classic-reset-row', function() {
                        var $row = $(this).closest('.mulopimfwc-classic-product-row');
                        resetRowFromSnapshot($row);
                    });

                    $(document).on('click', '.mulopimfwc-classic-save-row', function() {
                        var $row = $(this).closest('.mulopimfwc-classic-product-row');
                        if (!$row.hasClass('is-dirty')) {
                            return;
                        }

                        saveRow($row).done(function(response) {
                            if (response && response.data && response.data.message) {
                                showNotice(response.data.message, 'success');
                            }
                        }).fail(function(message) {
                            if (message) {
                                showNotice(message, 'error');
                            }
                        });
                    });

                    $('#mulopimfwc-classic-save-all').on('click', function() {
                        var $button = $(this);
                        var dirtyRows = $('.mulopimfwc-classic-product-row.is-dirty').toArray();
                        if (!dirtyRows.length) {
                            showNotice('<?php echo esc_js(__('No unsaved product rows.', 'multi-location-product-and-inventory-management')); ?>', 'info');
                            return;
                        }

                        $button.prop('disabled', true).text('<?php echo esc_js(__('Saving...', 'multi-location-product-and-inventory-management')); ?>');
                        var successCount = 0;
                        var errorCount = 0;
                        var index = 0;

                        function saveNext() {
                            if (index >= dirtyRows.length) {
                                $button.prop('disabled', false).text('<?php echo esc_js(__('Save All Product Changes', 'multi-location-product-and-inventory-management')); ?>');
                                if (errorCount > 0) {
                                    showNotice(successCount + ' <?php echo esc_js(__('rows saved,', 'multi-location-product-and-inventory-management')); ?> ' + errorCount + ' <?php echo esc_js(__('rows failed.', 'multi-location-product-and-inventory-management')); ?>', 'warning');
                                } else {
                                    showNotice('<?php echo esc_js(__('All changed product rows saved successfully.', 'multi-location-product-and-inventory-management')); ?>', 'success');
                                }
                                return;
                            }

                            var $row = $(dirtyRows[index]);
                            index++;
                            if (!$row.hasClass('is-dirty')) {
                                saveNext();
                                return;
                            }

                            saveRow($row).done(function() {
                                successCount++;
                                saveNext();
                            }).fail(function() {
                                errorCount++;
                                saveNext();
                            });
                        }

                        saveNext();
                    });

                    $('#mulopimfwc-classic-reset-all').on('click', function() {
                        var dirtyRows = $('.mulopimfwc-classic-product-row.is-dirty').toArray();
                        if (!dirtyRows.length) {
                            showNotice('<?php echo esc_js(__('No unsaved product rows.', 'multi-location-product-and-inventory-management')); ?>', 'info');
                            return;
                        }

                        dirtyRows.forEach(function(row) {
                            resetRowFromSnapshot($(row));
                        });

                        showNotice('<?php echo esc_js(__('All unsaved product row changes were reset.', 'multi-location-product-and-inventory-management')); ?>', 'success');
                    });
                });
            })(jQuery);
        </script>
<?php
    }
}
